#!/bin/sh
######################################################################
#
#  File:   power_diag.sh
#
#  Author: Rich Wang 
#
#  Date:   07/31/2012
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      This is the Power diagnostic test.
#
#
#  Routines:
#      display_power_menu   -  Display the options menu for power diagnostic
#      do_run_power_diag    -  Main routine for running power diagnostic
######################################################################

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# Power HAL Functions
[ -f ${_POWER_HAL_FUNCTIONS} ] && . ${_POWER_HAL_FUNCTIONS}

# WIFI HAL Functions
[ -f ${_WIFI_HAL_FUNCTIONS} ] && . ${_WIFI_HAL_FUNCTIONS}

# BT HAL Functions
[ -f ${_BT_HAL_FUNCTIONS} ] && . ${_BT_HAL_FUNCTIONS}

######################################################################
# Function:     display_power_menu
# Purpose:      Display the options menu for power diagnostic
# Parameters:    none
# Returns:      none
######################################################################
display_power_menu()
{
	banner="$PRODUCT_NAME Power Diagnostics"
	base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	do_local_echo "$banner"
	do_local_echo "$base"
    do_local_echo "W) Static Current Test"
    do_local_echo "T) Power Nominal mode"
    do_local_echo "$base"
    do_local_echo "X) Exit"
}


######################################################################
# Function:     do_run_power_diag
# Purpose:      Main routine for running power diagnostic.  It displays
#               the main power diagnostic menu and runs any power
#               sub-diagnostic tests based on operator request.
#               The menu contains items for the following:
#                   1) Power Nominal mode
#                   2) Static Current Test
# Parameters:    none
# Returns:      none
######################################################################
do_run_power_diag()
{
#    vmsg "do_run_power_diag()"
    REDRAW=0
    DRPG_DONE=0
    while [ $DRPG_DONE -ne 1 ]; do
		if [ $REDRAW -eq 0 ]; then
			display_power_menu
		else
		# REDRAW is a one-shot, so reset it now
			REDRAW=0
		fi
        KEY=`get_char`
        RETVAL=$?
        do_local_echo ""
        if [ $RETVAL -eq 0 ]; then
            case "$KEY" in
            	w | W)
            		do_measure_bt_wifi_static_current
            		;;
            		
                t | T)
                    do_run_power
                    # DRPG_DONE=1
                    ;;
                    
                x | X)
                    DRPG_DONE=1
                    ;;
                    
                *)
                    REDRAW=1;
                    ;;
            esac
        fi
    done
}


case "$1" in

    stop)
        vmsg "Exiting Power Diagnostic Test"
        return 0
        ;;
    start|*)
        vmsg "Starting Power Diagnostic Test"
        do_local_echo "Power Diagnostic Test:"
        power_hal_init
        do_run_power_diag
        power_hal_exit
        do_local_echo "You Exit Power Diagnostic Test"
        ;;

esac
