#!/bin/sh
#############################################################################
#
#  File:   test_511.sh
#
#  Author: Dennis.JL.Li
#
#  Date:   07/24/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      511 test station, in this station, it will collect some device setting 
#    information and create a logfile on the user store with device information.
#   
#   
#  Routines
#      gather_device_information()     - Gather device info and create a logfile
#      do_run_test_511_diag            - Display main test 511 menu, field requests
#
######################################################################


# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}


# 511 test HAL
[ -f ${_TEST_511_HAL_FUNCTIONS} ] && . ${_TEST_511_HAL_FUNCTIONS}


######################################################################
# Function:     gather_device_information
# Purpose:      Gather up information about the device, including
#                   Device Serial Number --> DEVICE_SERIAL_NUMBER
#                   Device PCB Id ---------> DEVICE_PCB_ID    
#                   DEVICE_WIFI_MAC_ADDRESS ---> DEVICE_WIFI_MAC_ADDRESS
#					DEVICE_BT_MAC_ADDRESS ---> DEVICE_BT_MAC_ADDRESS
# Parameters:    none
# Returns:      none
# Side Effect:  Loads up global variables noted above
######################################################################
gather_device_information()
{
	do_local_echo "Reading information from device ..."
	check_device_type
	dev_create_device_info_log
	dev_get_consumer_version
}

display_device_information()
{
    # Display device information now
	do_local_echo "Serial Number     : $DEVICE_SERIAL_NUMBER"
	do_local_echo "PCBA ID           : $DEVICE_PCB_ID"
	do_local_echo "WIFI SECRET       : $DEVICE_WIFI_SECRET"
	do_local_echo "WIFI MAC Address  : $DEVICE_WIFI_MAC_ADDRESS"
	do_local_echo "BT MAC Address    : $DEVICE_BT_MAC_ADDRESS"
	do_local_echo "APMAC Address     : $DEVICE_APMAC"
	do_local_echo "Software Version  : $DEVICE_SOFT_VERSION"
	
#	do_local_echo "calibration data0 : $DEVICE_AUDIO_CAL0"
#	do_local_echo "calibration data1 : $DEVICE_AUDIO_CAL1"
#	do_local_echo "calibration data2 : $DEVICE_AUDIO_CAL2"
#	do_local_echo "calibration data3 : $DEVICE_AUDIO_CAL3"
#	do_local_echo "calibration data4 : $DEVICE_AUDIO_CAL4"
#	do_local_echo "calibration data5 : $DEVICE_AUDIO_CAL5"
#	do_local_echo "calibration data6 : $DEVICE_AUDIO_CAL6"
}

######################################################################
# Function:     display_511_menu
# Purpose:      display the 511 menu
# Parameters:    none
# Returns:      none
######################################################################
display_511_menu()
{
    banner="$PRODUCT_NAME 511 Diagnostics"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    
	do_local_echo "$banner"
	gather_device_information ## always display all the information items regardless of pass fail
	do_local_echo "$base"
	
    display_device_information
	
    do_local_echo "$base"
    do_local_echo "X) Exit"	
}


######################################################################
# Function:     do_run_511_test_diag
# Purpose:      Gather up system information, display it to the user.
#               If device can not create device information log in 5 
#					seconds, show "FAIL" then back to main menu.
# Parameters:    none
# Returns:      none
######################################################################
do_run_511_test_diag()
{
    local DO_EXIT=0
    local REDRAW_MENU=0
    local start_time=`date +%s`
    local end_time=$((start_time+5))
    
    while [ $DO_EXIT -ne 1 ]; do
        if [ $REDRAW_MENU -eq 0 ]; then
			display_511_menu
			if [ `date +%s` -gt $end_time ]; then
				do_local_echo "Out of time create device information!"
				failure "511 test"
				DO_EXIT=1
			fi
        else
            REDRAW_MENU=1
        fi
        
        KEY=`get_char`
        echo " "
        case "$KEY" in
        
        x | X)
            DO_EXIT=1
            ;;
        
        *)
            REDRAW_MENU=0
            ;;
        
        esac
    done
}

case "$1" in

    stop)
        vmsg "Exiting 511_test Module"
        ;;
        
    cycle)
        vmsg "Cycle mode not supported by the 511_test Module"
        return 0
        ;;
        
    start|*)
        #do_local_echo "Starting 511_test Module"
        enter_diag "511_test"
        # Clear any previous diagnostic test results
        
        clear_diag_fail
        test_511_hal_init
        do_run_511_test_diag
        test_511_hal_exit
        
        exit_diag "511_test" 0
        ;;
        
esac
