#!/bin/sh
######################################################################################
#
#  File:   led_diag.sh
#
#  Author: Frank.Yi
#
#  Date:   2012.8.10
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the LED diagnostic.
#
#   Routines
#		led_diag_display_menu()     - Display the led diagnostic main menu
#		display_rgb_led_diag_menu() - Choose which colour to test
#		display_pass_fail_menu()    - Display the pass fail menu
#		rgb_led_diag()              - Test leds by colour
#		power_network_led_diag()    - Run power and nework LED test
#		mic_mute_led_diag()         - Test the Mic-mute LED
#		led_do_run_diag()           - Test leds by colour and set leds state for VI test
#
######################################################################################

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# LED HAL Functions
[ -f ${_LED_HAL_FUNCTIONS} ] && . ${_LED_HAL_FUNCTIONS}

######################################################################
# Function:     led_diag_display_menu
# Purpose:      Display the led diagnostic main menu.
# Parameters:    none
# Returns:      none
######################################################################
led_diag_display_menu()
{
    banner="$PRODUCT_NAME LED Diagnostic"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "A) LEDS Test by colour"
    do_local_echo "B) LED Driver Test1 - U24"
    do_local_echo "C) LED Driver Test2 - U24"
    do_local_echo "D) LED Driver Test1 - U25"
    do_local_echo "E) LED Driver Test2 - U25"
    do_local_echo "F) LED Driver Test1 - U26"
    do_local_echo "G) LED Driver Test2 - U26"
    do_local_echo "H) LED Driver Test1 - U27"
    do_local_echo "I) LED Driver Test2 - U27"
    do_local_echo "J) POWER and NETWORK LED"
    do_local_echo "K) DS1(Mic-mute LED) Test"
    do_local_echo "L) LED Self Test"

    do_local_echo "$base"
    do_local_echo "X) Exit"
}

######################################################################
# Function:     display_rgb_led_diag_menu
# Purpose:      Display the led diagnostic menu,choose which colour to test
# Parameters:    none
# Returns:      none
######################################################################
display_rgb_led_diag_menu()
{
    banner="$PRODUCT_NAME Testing LEDs by colour"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "W) Light all leds"
    do_local_echo "R) Light all red   leds"
    do_local_echo "G) Light all green leds"
    do_local_echo "B) Light all blue  leds"

    do_local_echo "$base"
    do_local_echo "X) Exit"
}

######################################################################
# Function:     display_power_network_led_diag_menu
# Purpose:      Display the power and network led diagnostic menu,
#               choose which colour to test
# Parameters:    none
# Returns:      none
######################################################################
display_power_network_led_diag_menu()
{
    banner="$PRODUCT_NAME Testing power and network led"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "O) power led on and network led off"
    do_local_echo "G) power led off and network led on"

    do_local_echo "$base"
    do_local_echo "X) Exit"
}

display_led_self_test_menu()
{
    banner="$PRODUCT_NAME LED Self Test"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "A) LED Controller 1 Self Test"
    do_local_echo "B) LED Controller 2 Self Test"
    do_local_echo "C) LED Controller 3 Self Test"
    do_local_echo "D) LED Controller 4 Self Test"

    do_local_echo "$base"
    do_local_echo "X) Exit"
}

######################################################################
# Function:     display_pass_fail_menu
# Purpose:      Display the pass fail menu.
# Parameters:    none
# Returns:      none
######################################################################
display_pass_fail_menu()
{
    banner="$PRODUCT_NAME Pass or fail?"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo  "P) PASS"
    do_local_echo  "F) FAIL"

    do_local_echo "$base"
    do_local_echo  "X) Exit"
}

run_led_self_test()
{
	local DISPLAY_MENU=0
	local NEED_RETURN=0
	local choice
	local base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	while [ $NEED_RETURN -ne 1 ]; do
		if [ $DISPLAY_MENU -eq 0 ]; then
		    display_led_self_test_menu
		else
		    DISPLAY_MENU=0
		fi
		choice=`get_char`
		do_local_echo
		case "$choice" in
			A | a )
				do_local_echo "LED Controller 1 Self Test Data:"
				do_local_echo "$base"
				led_self_test 1
				do_local_echo "$base"
				do_local_echo "Press 'Q' to continue..."
				wait_for_console_key q Q
			;;
			
			B | b )
				do_local_echo "LED Controller 2 Self Test Data:"
				do_local_echo "$base"
				led_self_test 2
				do_local_echo "$base"
				do_local_echo "Press 'Q' to continue..."
				wait_for_console_key q Q
			;;
			
			C | c )
				do_local_echo "LED Controller 3 Self Test Data:"
				do_local_echo "$base"
				led_self_test 3
				do_local_echo "$base"
				do_local_echo "Press 'Q' to continue..."
				wait_for_console_key q Q
			;;
			
			D | d )
				do_local_echo "LED Controller 4 Self Test Data:"
				do_local_echo "$base"
				led_self_test 4
				do_local_echo "$base"
				do_local_echo "Press 'Q' to continue..."
				wait_for_console_key q Q
			;;
			
			X | x )
				NEED_RETURN=1
				DISPLAY_MENU=1
				;;

			*)
				DISPLAY_MENU=1
				;;
		esac
				
				
	done
	
	
}
######################################################################
# Function:     rgb_led_diag
# Purpose:      Test leds by colour
# Parameters:    none
# Returns:      none
######################################################################
rgb_led_diag()
{
	local DISPLAY_MENU=0
	local NEED_RETURN=0
	local TEST_FAIL=0
	local colour_under_test
	while [ $NEED_RETURN -ne 1 ]; do
		if [ $DISPLAY_MENU -eq 0 ]; then
		    display_rgb_led_diag_menu
		else
		    DISPLAY_MENU=0
		fi
		cnt1=`get_char`
		do_local_echo
		case "$cnt1" in
			W | w )
			    led_set_brightness 75
				led_set_colour W
				colour_under_test="white"
				;;

			R | r )
			    led_set_brightness 150
				led_set_colour R
				colour_under_test="red"
				;;

			G | g )
			    led_set_brightness 150
				led_set_colour G
				colour_under_test="green"
				;;

			B | b )
			    led_set_brightness 150
				led_set_colour B
				colour_under_test="blue"
				;;

			X | x )
				NEED_RETURN=1
				DISPLAY_MENU=1
				;;

			*)
				DISPLAY_MENU=1
				;;
		esac
		# If operator had entered a test,then judge pass/fail.
		if [ $DISPLAY_MENU -eq 0 ]; then
			display_pass_fail_menu
			cnt2=`get_char`
			do_local_echo
			case "$cnt2" in
				P | p )
					success "$colour_under_test leds test"
					;;

				F | f )
					failure "$colour_under_test leds test"
					TEST_FAIL=1
					;;

				X | x )
					do_local_echo "Back to anterior menu."
					;;

				*)
					do_local_echo "Wrong input"
					;;
			esac
		fi
	done
	if [ $TEST_FAIL -eq 0 ];then
		success "RGB LEDS test"
	elif [ $TEST_FAIL -eq 1 ];then
		failure "RGB LEDS test"
	fi
    return 0
}

######################################################################
# Function:     power_network_led_diag
# Purpose:      Run power and network led test.
# Parameters:    none
# Returns:      none
######################################################################
power_network_led_diag()
{
	local DISPLAY_MENU=0
	local NEED_RETURN=0
	local TEST_FAIL=0
	while [ $NEED_RETURN -ne 1 ]; do
		if [ $DISPLAY_MENU -eq 0 ]; then
		    display_power_network_led_diag_menu
		else
		    DISPLAY_MENU=0
		fi
		local cnt1=`get_char`
		do_local_echo
		case "$cnt1" in
			O | o )
				${LED_DIAG_TOOL} -i 21 -c 1
				${LED_DIAG_TOOL} -i 21 -c 0
				${LED_DIAG_TOOL} -i 22 -c 7
			;;

			G | g )
				${LED_DIAG_TOOL} -i 21 -c 7
				${LED_DIAG_TOOL} -i 22 -c 1
				${LED_DIAG_TOOL} -i 22 -c 0
			;;

			X | x ) 
				NEED_RETURN=1 
				DISPLAY_MENU=1
			;;

			*)
				DISPLAY_MENU=1
			;;
		esac
		# If operator had entered a test,then judge pass/fail.
		if [ $DISPLAY_MENU -eq 0 ]; then
			display_pass_fail_menu
			local cnt2=`get_char`
			do_local_echo
			case "$cnt2" in
				P | p )
					case "$cnt1" in
						O | o )
							success "power led on and network led off"
						;;
						G | g )
							success "power led off and network led on"
						;;
					esac
					;;

				F | f )
					case "$cnt1" in
						O | o )
							failure "power led on and network led off"
						;;
						G | g )
							failure "power led off and network led on"
						;;
					esac
					TEST_FAIL=1
					;;

				X | x )
					do_local_echo "Back to anterior menu."
					;;

				*)
					do_local_echo "Wrong input."
					;;
			esac
		fi
	done
	return 0
}

######################################################################
# Function:     mic_mute_led_diag
# Purpose:      Ask the Operator to press and release Mic-mute button 
#               and check the led.
# Parameters:    none
# Returns:      none
######################################################################
mic_mute_led_diag()
{
	do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	do_local_echo "Please press and release Mic-mute button"
	do_local_echo "Press $SUCCESS_KEY if the Mic-mute LED works well"
	do_local_echo "Press $FAILURE_KEY if the LED does not light"
	key=`get_char`
	do_local_echo
	case "$key" in
		$SUCCESS_KEY_LABEL)
			success "DS1(Mic-mute LED)"
			;;
			
		$FAILURE_KEY_LABEL)
			failure "DS1(Mic-mute LED)"
			;;
			
		*)
			do_local_echo "Wrong input. "
			do_local_echo "back to main menu..."
			;;
	esac
	do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	do_local_echo "Please press the Mic-mute button again to"
	do_local_echo "turn off the Mic-mute LED if necessary"
	do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
}

######################################################################
# Function:     led_do_run_diag
# Purpose:      Test leds by colour and set leds state for V-I test
# Parameters:    none
# Returns:      none
######################################################################
led_do_run_diag()
{
	local DO_RETURN=0
	local DONT_REDRAW_MENU=0 
	
	while [ $DO_RETURN -ne 1 ]; do
		if [ $DONT_REDRAW_MENU -eq 0 ]; then
		    led_diag_display_menu
		else
		    DONT_REDRAW_MENU=0
		fi
		key=`get_char`
		do_local_echo
		case "$key" in
			A | a )
			rgb_led_diag
			;;

			B | b )
			led_set_state 1 $STATE1
			do_local_echo "Set LED controller 1 outputs to $STATE1"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U24 1
			;;
			
			C | c )
			led_set_state 1 $STATE2
			do_local_echo "Set LED controller 1 outputs to $STATE2"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U24 2
			;;

			D | d )
			led_set_state 2 $STATE1
			do_local_echo "Set LED controller 2 outputs to $STATE1"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U25 1
			;;

			E | e )
			led_set_state 2 $STATE2
			do_local_echo "Set LED controller 2 outputs to $STATE2"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U25 2
			;;

			F | f )
			led_set_state 3 $STATE1
			do_local_echo "Set LED controller 3 outputs to $STATE1"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U26 1
			;;

			G | g )
			led_set_state 3 $STATE2
			do_local_echo "Set LED controller 3 outputs to $STATE2"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U26 2
			;;

			H | h )
			led_set_state 4 $STATE1
			do_local_echo "Set LED controller 4 outputs to $STATE1"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U27 1
			;;

			I | i )
			led_set_state 4 $STATE2
			do_local_echo "Set LED controller 4 outputs to $STATE2"
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			#set_state U27 2
			;;

			J | j )
			power_network_led_diag
			;;

			K | k )
			mic_mute_led_diag
			;;
			
			L | l )
			run_led_self_test
			;;

			X | x )
			DO_RETURN=1
			;;

			* )
			DONT_REDRAW_MENU=1
			;;
		esac
	done
}

case "$1" in

    stop)
		vmsg "Exiting LED Diagnostic"
		;;

    start|*)
		vmsg "Displaying led Diagnostic Services Menu"
		enter_diag "LED"
		# Clear any previous diagnostic test results
		clear_diag_fail
		led_hal_init
		RETVAL=$?
		if [ "$RETVAL" -eq 0 ]; then
			#Run LED diag
			led_do_run_diag
		fi
		led_hal_exit
		exit_diag "LED" 0
		did_diag_fail
		diag_test_failed="$?"
		return $diag_test_failed
		;;
esac
