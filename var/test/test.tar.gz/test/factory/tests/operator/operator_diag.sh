#!/bin/sh
######################################################################
#
#  File:   operaror_diag.sh
#
#  Author: Linda Ru
#
#  Date:   07/25/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the operator diagnostic.
#
#
#   Routines
#       operator_diag_display_menu()       - Display main operator diagnostic menu
#       led_speaker_get_process_choice()   - Get the operator response,select pass or fail 
#       led_speaker_display_menu_before()  - show menu to tell operator what to do
#       led_speaker_display_menu_after()   - show menu to tell operator select pass or fail 
#       do_run_operator_diag()             - Display the main operator diagnostic menu, respond        
#                                            operator requests and run any sub-test requests.
#       do_operator_mic_diag()             - record wav file and play to check whether mic is ok 
#       do_led_speaker_diag()              - test led(rgb) and left,right,stereo speaker 
######################################################################

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}
# Sound HAL Functions
[ -f ${_AUDIO_HAL_FUNCTIONS} ] && . ${_AUDIO_HAL_FUNCTIONS}
#Button HAL Functions
[ -f ${_BUTTON_HAL_FUNCTIONS} ] && . ${_BUTTON_HAL_FUNCTIONS}
#I2C scan Functions
[ -f ${_I2C_SCAN_HAL_FUNCTIONS} ] && . ${_I2C_SCAN_HAL_FUNCTIONS}
#Operator test Functions
[ -f ${_OPERATOR_HAL_FUNCTIONS} ] && . ${_OPERATOR_HAL_FUNCTIONS}
# LED HAL Functions
[ -f ${_LED_HAL_FUNCTIONS} ] && . ${_LED_HAL_FUNCTIONS}

#
# Sound channel constants for use as parameter when calling
#    enable_channel() and disable_channel()
#

#export LED_DIAG_TOOL=$DIAG_TOOL_ROOT/led
export I2C_SCAN_TOOL=$DIAG_TOOL_ROOT/i2cscan

######################################################################
# Function:     operator_diag_display_menu
# Purpose:      Display the main operater diagnostic menu.
# Parameters:    none
# Returns:      none
######################################################################
operator_diag_display_menu()
{
    banner="DOPPLER Operator test suite"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"
    do_local_echo "A) Peripheral test(I2C devices scan)"
    do_local_echo "B) Volumn button test"
    do_local_echo "C) Alexa Button test"
    do_local_echo "D) MICROPHONE-MUTE button test"
#    do_local_echo "E) WPS button test"
    do_local_echo "F) Reset button test"
    do_local_echo "G) LED red & left speaker test"
    do_local_echo "H) LED green & right speaker test"
    do_local_echo "I) LED blue &  both speakers test"
    do_local_echo "J) Microphone test"
    do_local_echo "$base"
	
    do_local_echo "PANCAKE Operator test suite"
    do_local_echo "$base"
    do_local_echo "K) Peripheral test(I2C devices scan)"
    do_local_echo "L) LED red test"
    do_local_echo "M) LED green test"
    do_local_echo "N) LED blue test"
	do_local_echo "P) Pancake Microphone test"
	do_local_echo "Q) Bluetooth Scan"
	do_local_echo "R) WiFi Scan"
	do_local_echo "S) Als Read"
    do_local_echo "$base"
    do_local_echo "X) Exit"
}


######################################################################
# Function:     do_run_operator_diag()
# Purpose:      Display the main operator diagnostic menu, field operator
#               requests and run any sub-test requests.
# Parameters:    none
# Returns:      none
######################################################################
do_run_operator_diag()
{
  DO_RETURN=0
  DONT_REDRAW_MENU=0 

  while [ $DO_RETURN -ne 1 ]; do

    # Put up the splash screen if we're manually starting up the framework.
    #
    if [ $DONT_REDRAW_MENU -eq 0 ]; then
        operator_diag_display_menu
    else
        # DONT_REDRAW_MENU is a one-shot, so reset it now
        DONT_REDRAW_MENU=0
    fi

 
    #
    # Get the key request
    #
    KEY=`get_char`
    do_local_echo
    #
    # Process key request
    case "$KEY" in

    a | A)
        # I2C scan test
        do_ten_i2c_scan "MAIN" "AUDIO" "CONN"
        ;;

    b | B)
        # Volume button test... code value is 0
        check_button_press
        do_test_button ${VOL_UP}
        sleep 1
        do_test_button ${VOL_DOWN}
        ;;
        
    c | C)
        # Alexa Button test... help Button,code value is 138
        do_test_button $ALEXA
        ;;

    d | D)
        # MICROPHONE-MUTE button test...code value is 113
        do_test_button $MUTE
        ;;

#    e | E)
        # WPS button test...
#        do_test_button $WPS
#        ;;

    f | F)
		#Reset button test...
		run_reset_button_diag
        ;;

    g | G)
        # LED red & left speaker test...
        do_led_speaker_diag ${CHANNEL_SPEAKER_LEFT} ${OP_VOLUME} ${OPETATOR_LEFT_AUDIO_FILE} 
        ;;

    h | H)
        # LED green & right speaker test...
        do_led_speaker_diag ${CHANNEL_SPEAKER_RIGHT} ${OP_VOLUME} ${OPETATOR_RIGHT_AUDIO_FILE} 
        ;;

    i | I)
        # LED bule &  both speaker test
        do_led_speaker_diag ${CHANNEL_SPEAKER_STEREO} ${OP_VOLUME} ${OPETATOR_STEREO_AUDIO_FILE} 
        ;;
        
    j | J)
        # Microphone test
        do_operator_mic_diag 1
        ;;
		
	k | K)
		do_ten_i2c_scan "MAIN" "AUDIO"
        ;;
        
	l | L)
		led_set_colour R
        ;;
        
	m | M)
		led_set_colour G
        ;;
        
	n | N)
		led_set_colour B
        ;;
		
	p | P)
		do_operator_mic_diag 2
		;;
		
	q | Q)
		do_bluetooth_scan
		;;
	
	r | R)
	    do_wifi_scan
	    ;;
	    
	s | S)
	    do_als_read
	    ;;    
     
    x | X)
        vmsg "Generate test log"	    
		DO_RETURN=1
        ;;

    *)
        DONT_REDRAW_MENU=1
        ;;

    esac
done

}

export OPERATOR_LOG_OUTPUT_TO_LOGFILE=1

case "$1" in

    stop)
        vmsg "Exiting Operator test suite"
        ;;

    start|*)
        vmsg "Enter Operator test suite"
        enter_diag "Operator suite"
        # Clear any previous diagnostic test results
        clear_diag_fail
        audio_hal_init
        RETVAL=$?
        if [ "$RETVAL" -eq 0 ]; then
            do_run_operator_diag
        else
            show_hal_init_failure_message "$RETVAL"
        fi
        exit_diag "Operator suite" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        export OPERATOR_LOG_OUTPUT_TO_LOGFILE=0
        ;;
esac


