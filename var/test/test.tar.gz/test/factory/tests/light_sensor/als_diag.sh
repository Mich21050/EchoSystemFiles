#!/bin/sh
######################################################################################
#
#  File:   led_diag.sh
#
#  Author: Frank.Yi
#
#  Date:   2013.11.15
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the Ambient Light Sensor Calibration and LED uniformity test.
#
######################################################################################

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# LED HAL Functions
[ -f ${_ALS_HAL_FUNCTIONS} ] && . ${_ALS_HAL_FUNCTIONS}

als_cal_display_menu()
{
    banner="$PRODUCT_NAME ALS&LED Diagnostic"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "A) RED   LED uniformity test"
    do_local_echo "B) GREEN LED uniformity test"
    do_local_echo "C) BLUE  LED uniformity test"

	do_local_echo "D) ALS Calibration"
	do_local_echo "E) Store ALS value"
	do_local_echo "S) Check ALS Data"
    do_local_echo "V) Light sensor BIST when device LEDS off"
	do_local_echo "W) Light sensor BIST when device LEDS on"

    do_local_echo "$base"
    do_local_echo "X) Exit"
}

als_cal_diag()
{
	local DO_RETURN=0
	local DONT_REDRAW_MENU=0
	local key
	
	while [ $DO_RETURN -ne 1 ]; do
		if [ $DONT_REDRAW_MENU -eq 0 ]; then
		    als_cal_display_menu
		else
		    DONT_REDRAW_MENU=0
		fi
		key=`get_char`
		do_local_echo
		case "$key" in
			"A" | "a" )
			led_uniformity R
			;;

			"B" | "b" )
			led_uniformity G
			;;
			
			"C" | "c" )
			led_uniformity B
			;;
			
			"D" | "d" )
			run_als_cal
			;;

			"E" | "e" )
			store_als_idme
			;;
			
			"S" | "s" )
			check_als_result
			;;
			
			V | v )
			# audio boad FCT light sensor V&I test interface
			led_set_colour "D"
			sleep 1
			als-read
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			;;
			
			W | w )
			# audio boad FCT light sensor V&I test interface2
			led_set_colour "W"
			led_set_brightness 150
			sleep 1
			als-read
			do_local_echo "Press 'Q' to continue..."
			wait_for_console_key q Q
			led_set_colour "D"
			;;

			X | x )
			DO_RETURN=1
			;;

			* )
			DONT_REDRAW_MENU=1
			;;
		esac
	done
}

case "$1" in

    stop)
		vmsg "Exiting ALS Diagnostic"
		;;

    start|*)
		vmsg "Displaying ALS Diagnostic Services Menu"
		enter_diag "ALS Calibration"
		# Clear any previous diagnostic test results
		clear_diag_fail
		als_hal_init
		RETVAL=$?
		if [ "$RETVAL" -eq 0 ]; then
			#Run ALS Calibration diagnostic
			als_cal_diag
		fi
		als_hal_exit
		exit_diag "ALS Calibration" 0
		did_diag_fail
		diag_test_failed="$?"
		return $diag_test_failed
		;;
esac
