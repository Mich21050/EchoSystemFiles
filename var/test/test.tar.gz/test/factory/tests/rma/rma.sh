#!/bin/sh
######################################################################
#
#  File:   rma.sh
#
#  Author: Linda Ru
#
#  Date:   04/23/2013
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      This is the RMA station diagnostic.
#
#  Routines:
#    wifi_scan_ssid()         -wifi scan ssid
#    bt_scan_mac()           -bt scan mac
#    rma_swdl_test()         -user swdl
#    get_rma_message()  -Load the dsn,wifi mac,bt mac,ap mac
#    do_run_rma()            -rma main function
#    display_rma_menu()  -display rma menu
#    check_sw_version()    -check user sw version
#
######################################################################

# 511 test HAL
[ -f ${_TEST_511_HAL_FUNCTIONS} ] && . ${_TEST_511_HAL_FUNCTIONS}
# Sdram HAL Functions
[ -f ${_SDRAM_HAL_FUNCTIONS} ] && . ${_SDRAM_HAL_FUNCTIONS}
# BT HAL Functions
[ -f ${_BT_HAL_FUNCTIONS} ] && . ${_BT_HAL_FUNCTIONS}
#Button HAL Functions
[ -f ${_BUTTON_HAL_FUNCTIONS} ] && . ${_BUTTON_HAL_FUNCTIONS}
#I2C scan Functions
[ -f ${_I2C_SCAN_HAL_FUNCTIONS} ] && . ${_I2C_SCAN_HAL_FUNCTIONS}
#Operator test Functions
[ -f ${_OPERATOR_HAL_FUNCTIONS} ] && . ${_OPERATOR_HAL_FUNCTIONS}
# LED HAL Functions
[ -f ${_LED_HAL_FUNCTIONS} ] && . ${_LED_HAL_FUNCTIONS}
# Software update HAL Functions
[ -f ${_SOFTWARE_UPDATE_HAL_FUNCTIONS} ] && . ${_SOFTWARE_UPDATE_HAL_FUNCTIONS}


load_wifi_driver()
{
	local wifi_driver_dir="/lib/modules/2.6.37"
    local ret=0
	insmod ${wifi_driver_dir}/compat.ko
	sleep 2
	if ! `lsmod | grep "compat" > /dev/null 2>&1`; then
		ret=1
	fi
	
	insmod ${wifi_driver_dir}/cfg80211.ko
	sleep 2
	if ! `lsmod | grep "cfg80211" > /dev/null 2>&1`; then
		ret=1
	fi	
	
	insmod ${wifi_driver_dir}/ath6kl_sdio.ko
	sleep 2	
	if ! `lsmod | cut -d " " -f1 | grep "ath6kl_sdio" > /dev/null 2>&1`; then
		ret=1
	fi	
	
	return $ret
}

remove_wifi_driver()
{
	rmmod ath6kl_sdio > /dev/null 2>&1
	rmmod cfg80211 > /dev/null 2>&1
	rmmod compat > /dev/null 2>&1		
}

wifi_scan_ssid()
{
	do_local_echo "loading wifi driver..."
	load_wifi_driver
	if [ $? -ne 0 ];then
		do_local_echo "wifi power on fail"
		failure "wifi test"
		remove_wifi_driver
		return 1
	fi
	ifconfig wlan0 up > /dev/null 2>&1
	sleep 2
	ifconfig  | grep "wlan0" > /dev/null 2>&1
	if [ $? -ne 0 ];then
		do_local_echo "bring up wlan0 fail"
		failure "wifi test"
		remove_wifi_driver
		return 1
	fi
	do_local_echo "wifi power on success"
	do_local_echo "scanning access point..."
	iw wlan0 scan | grep "SSID"
	if [ $? -eq 0 ];then
		success "wifi test"
	else
		do_local_echo "no access point found"
		failure "wifi test"
	fi
	remove_wifi_driver
	return 0
}

######################################################################
# Function:     bt_scan_mac
# Purpose:      bt scan mac
# Parameters:   none
# Returns:      none
######################################################################
bt_scan_mac()
{
	do_bt_power_on
	local RETVAL=$?
	if [ $RETVAL -eq 0 ];then
		do_local_echo "scanning BT devices around..."
		hcitool scan
	else
		failure "BT test"
	fi
}

######################################################################
# Function:     get_rma_message
# Purpose:      Load the dsn,wifi mac,bt mac,ap mac
# Parameters:   none
# Returns:      none
######################################################################
get_rma_message()
{
	dev_get_serial_number
	dev_get_apmac
	dev_get_mac_address
    do_local_echo "Serial Number     : $DEVICE_SERIAL_NUMBER"
	do_local_echo "WIFI MAC Address  : $DEVICE_WIFI_MAC_ADDRESS"
	do_local_echo "BT MAC Address    : $DEVICE_BT_MAC_ADDRESS"
	do_local_echo "APMAC Address     : $DEVICE_APMAC"
}


######################################################################
# Function:     check_sw_version
# Purpose:      check sw version
# Parameters:   none
# Returns:      none
######################################################################
check_sw_version()
{
	check_swdl_version
}


######################################################################
# Function:     rma_swdl_test
# Purpose:      swdl
# Parameters:   none
# Returns:      none
######################################################################
rma_swdl_test()
{
    software_update_hal_init
	run_swdl
}


######################################################################
# Function:     display_rma_menu
# Purpose:      display rma menu
# Parameters:   none
# Returns:      none
######################################################################
display_rma_menu()
{
    banner="$PRODUCT_NAME RMA Test"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    do_local_echo "A) Peripheral Test"
    do_local_echo "B) Volume Button Test"
    do_local_echo "C) Alexa Button Test"
    do_local_echo "D) Mic-Mute Button Test"
    do_local_echo "E) Reset Button Test"
    do_local_echo "F) LED Red & Left Speaker Test"
    do_local_echo "G) LED Green & Right Speaker Test"
    do_local_echo "H) LED Blue & Both Speaker Test"
    do_local_echo "I) Microphone Test"
    do_local_echo "J) SDRAM Test"
    do_local_echo "K) WIFI Test"
    do_local_echo "L) BT Test"
    do_local_echo "M) MMC Bundle install"
    do_local_echo "N) Return SW Version"
    do_local_echo "O) Check Pass/Fail Status"
    do_local_echo "P) Reboot System"
    do_local_echo "Q) Disable Diags"
 
    do_local_echo "$base"
    do_local_echo "X) Exit"
}



######################################################################
# Function:     do_run_rma
# Purpose:      rma test
# Parameters:   none
# Returns:      none
######################################################################
do_run_rma()
{
	local DO_RETURN=0
	local DONT_REDRAW_MENU=0 
	get_rma_message	
	
	while [ $DO_RETURN -ne 1 ]; do

    # Put up the splash screen if we're manually starting up the framework.
    #
    if [ $DONT_REDRAW_MENU -eq 0 ]; then
        display_rma_menu
    else
        # DONT_REDRAW_MENU is a one-shot, so reset it now
        DONT_REDRAW_MENU=0
    fi

 
    #
    # Get the key request
    #
    local KEY=`get_char`
    do_local_echo
    #
    # Process key request
    case "$KEY" in
       
     a | A)
        # I2C scan test
        do_ten_i2c_scan
        ;;

    b | B)
        # Volume button test... code value is 0
        do_test_button ${VOL_UP}
        sleep 1
        do_test_button ${VOL_DOWN}
        ;;
        
    c | C)
        # Alexa Button test... help Button,code value is 138
        do_test_button $ALEXA
        ;;

    d | D)
        # MICROPHONE-MUTE button test...code value is 113
        do_test_button $MUTE
        ;;

    e | E)
		#Reset button test...
		run_reset_button_diag
        ;;

    f | F)
        # LED red & left speaker test...
        do_led_speaker_diag ${CHANNEL_SPEAKER_LEFT} ${OP_VOLUME} ${OPETATOR_LEFT_AUDIO_FILE} 
        ;;

    g | G)
        # LED green & right speaker test...
        do_led_speaker_diag ${CHANNEL_SPEAKER_RIGHT} ${OP_VOLUME} ${OPETATOR_RIGHT_AUDIO_FILE} 
        ;;

    h | H)
        # LED bule &  both speaker test
        do_led_speaker_diag ${CHANNEL_SPEAKER_STEREO} ${OP_VOLUME} ${OPETATOR_STEREO_AUDIO_FILE} 
        ;;
        
    i | I)
        # Microphone test
        do_operator_mic_diag 1
        ;;
        
     j | J)
        # sdram test
		sdram_do_run_diag
        ;;
        
    k | K)
        # wifi test
        wifi_scan_ssid
        ;;
        
	l | L)
        # bt test	
		bt_scan_mac
        ;;  
        
    m | M)
		#mmc bundle install
		rma_swdl_test
        ;;
        
    n | N)
		#return sw version
		check_sw_version
        ;;
        
	o | O)
		#check pass/fail
		display_diag_result_summary
        ;;
 
     p | P)
		#reboot
		reboot
        ;;
        
    q | Q)
		#disable diags
		disable_diags
        ;;
        
     x | X)
        vmsg "Exiting RMA Diagnostic Test..."
	    DO_RETURN=1
        ;;

    *)
        DONT_REDRAW_MENU=0
        ;;

    esac
  done

}

case "$1" in

    stop)
        vmsg "Exiting RMA Diagnostic Tests"
        ;;

    start|*)
        enter_diag "RMA Test"
        # Clear any previous diagnostic test results
        clear_diag_fail
        audio_hal_init
        do_run_rma
        ;;
esac
