#!/bin/sh
####################################################################################
#
#  File:   run_modes_diag.sh
#
#  Author: Linda Ru 
#
#  Date:   07/5/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#
#  Description:
#      Contains the run modes diagnostics, which includes various
#       run modes and the run-in test.

#
#   Routines
#       rm_display_menu()               - Display the run modes menu
#       set_run_in_default_options()    - Enable run-in componets based on defaults
#       adjust_run_in_options()         - Allow user to change which components get
#                                         tested in the run-in test.
#		display_runin_time_menu()       - Display runin time menu
#       do_run_in_mode()                - Run the run-in test
#       do_save_runin_args()            - Save runin args
#       do_set_run_in_time()            - Allow operator to set runin time,2 hours by default
####################################################################################

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# Run Modes HAL Functions
[ -f ${_RUN_MODES_HAL_FUNCTIONS} ] && . ${_RUN_MODES_HAL_FUNCTIONS}

# Constants used when executing sub-tests via do_run_in_subtest() calls


######################################################################
# Function:     set_run_in_default_options
# Purpose:      Setup the run-in tests default options 
# Parameters:    none
# Returns:      none
######################################################################
set_run_in_default_options()
{
	export RUN_IN_BT_ON_ENABLE=$RUN_IN_BT_ON_ENABLE_DEFAULT
	export RUN_IN_BT_OFF_ENABLE=$RUN_IN_BT_OFF_ENABLE_DEFAULT
	export RUN_IN_WIFI_ON_ENABLE=$RUN_IN_WIFI_ON_ENABLE_DEFAULT
	export RUN_IN_WIFI_OFF_ENABLE=$RUN_IN_WIFI_OFF_ENABLE_DEFAULT
	export RUN_IN_I2CSCAN_ENABLE=$RUN_IN_I2CSCAN_ENABLE_DEFAULT
    export RUN_IN_AUDIO_ENABLE=$RUN_IN_AUDIO_ENABLE_DEFAULT
#   export RUN_IN_RGB_ENABLE=$RUN_IN_RGB_ENABLE_DEFAULT
}


######################################################################
# Function:     rm_display_menu
# Purpose:      Display the main run modes menu
# Parameters:    none
# Returns:      none
######################################################################
rm_display_menu()
{
	banner="$PRODUCT_NAME Runin Test V${RUN_IN_VERSION}"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"	
	do_local_echo "A) Peripheral test ${RUN_IN_I2CSCAN_ENABLE}"
	do_local_echo "B) BT Power On ${RUN_IN_BT_ON_ENABLE}"
	do_local_echo "C) BT Power Off ${RUN_IN_BT_OFF_ENABLE}"
	do_local_echo "D) WIFI Power On ${RUN_IN_WIFI_ON_ENABLE}"
	do_local_echo "E) WIFI Power Off ${RUN_IN_WIFI_OFF_ENABLE}"
#	do_local_echo "F) LED RGB BLINK ${RUN_IN_RGB_ENABLE}"
	do_local_echo "G) Audio test ${RUN_IN_AUDIO_ENABLE}"
	do_local_echo "Q) to continue"
	do_local_echo "$base"	
	do_local_echo "X) Exit"
}


######################################################################
# Function:     display_runin_time_menu
# Purpose:      Display the runin time menu
# Parameters:    none
# Returns:      none
######################################################################
display_runin_time_menu()
{
	banner="$PRODUCT_NAME Runin Test choose test time"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"
	do_local_echo "A) 2 hours"
	do_local_echo "B) 3 minutes"
	do_local_echo "C) 30 minutes"
	do_local_echo "D) 24 hours"
	do_local_echo "E) 7 days"
	do_local_echo "F) 4 weeks"
	#do_local_echo "Q) to continue"
	do_local_echo "$base"
	do_local_echo "X) Exit"	
}


######################################################################
# Function:     do_set_run_in_time
# Purpose:      Allow user to specify a new duration for the lenght of
#               the run-in test (2 hours by default)
# Parameters:   none
# Returns:      none
######################################################################
do_set_run_in_time()
{
	DONE=0
    _DO_REDRAW=1
    while [ $DONE -ne 1 ]; do
        if [ $_DO_REDRAW -eq 1 ]; then
			display_runin_time_menu
        fi

        # Process key request
		vmsg "set runin time"
		key=`get_char`
		do_local_echo
		case "$key" in
			a | A) 
			export RUN_IN_TIME=`expr 3600 \* 2`
			RUN_IN_TIME_LABEL="2 hours"
			;;
			b | B) 
			export RUN_IN_TIME=`expr 60 \* 3`
			RUN_IN_TIME_LABEL="3 minutes"
			;;
			c | C) 
			export RUN_IN_TIME=`expr 60 \* 30`
			RUN_IN_TIME_LABEL="30 minutes"
			;;
			d | D) 
			export RUN_IN_TIME=`expr 3600 \* 24`
			RUN_IN_TIME_LABEL="24 hours"
			;;
			e | E) 
			export RUN_IN_TIME=`expr 3600 \* 24 \* 7`
			RUN_IN_TIME_LABEL="7 days"
			;;
			f | F) 
			export RUN_IN_TIME=`expr 3600 \* 24 \* 7 \* 4`
			RUN_IN_TIME_LABEL="4 weeks"
			;;
		#	q | Q)
		#	vmsg "begin runin test" 
		#	DONE=1			
		#	return 0
		#	;;
			x | X)
			return 1
			;;
		esac
		do_local_echo "Runin time is ${RUN_IN_TIME_LABEL}"
    done				
}


######################################################################
# Function:     do_save_runin_args
# Purpose:      Save runin args to filesystem.
# Parameters:    none
# Returns:      none
######################################################################
do_save_runin_args()
{
	export SAVE_RUNIN_ARG=1
	do_local_echo "I2C=$RUN_IN_I2CSCAN_ENABLE" #RUN_IN_I2CSCAN_ENABLE
	do_local_echo "BON=$RUN_IN_BT_ON_ENABLE" #RUN_IN_BT_ON_ENABLE
	do_local_echo "BOF=$RUN_IN_BT_OFF_ENABLE" #RUN_IN_BT_OFF_ENABLE
	do_local_echo "WON=$RUN_IN_WIFI_ON_ENABLE" #RUN_IN_WIFI_ON_ENABLE
	do_local_echo "WOF=$RUN_IN_WIFI_OFF_ENABLE" #RUN_IN_WIFI_OFF_ENABLE
    do_local_echo "AUDIO=$RUN_IN_AUDIO_ENABLE" #RUN_IN_AUDIO_ENABLE
#    do_local_echo "RGB=$RUN_IN_RGB_ENABLE" #RUN_IN_RGB_ENABLE
	do_local_echo "TIM=$RUN_IN_TIME" #RUN_IN_TIME
	export SAVE_RUNIN_ARG=0
}


######################################################################
# Function:     adjust_run_in_options
# Purpose:      Display screen to allow operator to enable or disable
#               various components for the run-in test.
# Parameters:    none
# Returns:      none
# Side Effect:  Sets the RUN_IN_XXX_ENABLED variable based on operator
#               response.
######################################################################
adjust_run_in_options()
{
    # Setup product-defined defaults
    set_run_in_default_options

    # Loop until user is done configuring test options...
    DONE=0
    _DO_REDRAW=1
    while [ $DONE -ne 1 ]; do
        if [ $_DO_REDRAW -eq 1 ]; then
			rm_display_menu
        fi

        # Get the key request
        KEY=`get_char`
        do_local_echo
            # Process key request
            case "$KEY" in
                a | A)
                    if [ "$RUN_IN_I2CSCAN_ENABLE" == "ENABLE" ]; then
                        export RUN_IN_I2CSCAN_ENABLE="DISABLE"
                    else
                        export RUN_IN_I2CSCAN_ENABLE="ENABLE"
                    fi
                    ;;
                b | B)
                    if [ "$RUN_IN_BT_ON_ENABLE" == "ENABLE" ]; then
                        export RUN_IN_BT_ON_ENABLE="DISABLE"
                    else
                        export RUN_IN_BT_ON_ENABLE="ENABLE"
                    fi
                    ;;
                c | C)
                    if [ "$RUN_IN_BT_OFF_ENABLE" == "ENABLE" ]; then
                        export RUN_IN_BT_OFF_ENABLE="DISABLE"
                    else
                        export RUN_IN_BT_OFF_ENABLE="ENABLE"
                    fi
                    ;;
                d | D)                    
                    if [ "$RUN_IN_WIFI_ON_ENABLE" == "ENABLE" ]; then
                        export RUN_IN_WIFI_ON_ENABLE="DISABLE"
                    else
                        export RUN_IN_WIFI_ON_ENABLE="ENABLE"
                    fi
                    ;;
                e | E)
                    if [ "$RUN_IN_WIFI_OFF_ENABLE" == "ENABLE" ]; then
                        export RUN_IN_WIFI_OFF_ENABLE="DISABLE"
                    else
                        export RUN_IN_WIFI_OFF_ENABLE="ENABLE"
                    fi
                    ;;  
 #               f | F)                                                          
 #                   if [ "$RUN_IN_RGB_ENABLE" == "ENABLE" ]; then          
 #                       export RUN_IN_RGB_ENABLE="DISABLE"                 
 #                   else                                                       
 #                       export RUN_IN_RGB_ENABLE="ENABLE"             
 #                   fi                                                     
 #                   ;;              
                g | G)                                                          
                    if [ "$RUN_IN_AUDIO_ENABLE" == "ENABLE" ]; then          
                        export RUN_IN_AUDIO_ENABLE="DISABLE"                 
                    else                                                       
                        export RUN_IN_AUDIO_ENABLE="ENABLE"             
                    fi                                                     
                    ;; 
                q | Q)
					do_set_run_in_time
					if [ $? -eq 0 ];then
						return 0
				    fi
                    ;;
           
                x | X)
					return 1
                    ;;

                *)
                    vmsg "Wrong key $KEY pressed"
                    ;;
            esac
    done 
}


######################################################################
# Function:     do_run_in_mode
# Purpose:      Run the main run modes diagnostic, displaying a menu
#               and allowing operator to choose test.
# Parameters:    none
# Returns:		0 - test passed
#               1 - tests failed
######################################################################
do_run_in_mode()
{
    # Display options set for run-in, allowing user to change
    open_save_runin_log
    adjust_run_in_options
    RETVAL_ADJUST=$?
    do_local_echo $RETVAL_ADJUST
    if [ $RETVAL_ADJUST -eq 0 ];then  
		do_auto_runin_test
		RESULT="$?"
        runin_display_result_dialog "$RESULT"
	else 
		do_save_runin_args
	fi
	close_save_runin_log
	
}


case "$1" in

    stop)
        vmsg "Exiting Run Modes"
        ;;

    start|*)
        vmsg "Starting Run Modes"
        enter_diag "Run Modes"
        # Clear any previous diagnostic test results
        clear_diag_fail
        run_modes_hal_init
        do_run_in_mode
        exit_diag "Run Modes" 0
        ;;
esac
