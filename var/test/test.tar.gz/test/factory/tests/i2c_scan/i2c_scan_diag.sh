#!/bin/sh
######################################################################
#
#  File:   i2c_scan_diag.sh
#
#  Author: Rich Wang
#
#  Date:   08/01/2012
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      This is the I2C Scan diagnostic test.
#
#
#  Routines:
#      display_i2c_scan_menu - Display the options menu for i2c scan diagnostic
#      do_i2c_scan           - Scan the board that operator has selected, to
#                              watch whether all slave devices are in it.
#      i2c_scan_do_run_diag  - Main routine for running i2c scan diagnostic
######################################################################

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# I2C scan HAL Functions
[ -f ${_I2C_SCAN_HAL_FUNCTIONS} ] && . ${_I2C_SCAN_HAL_FUNCTIONS}


######################################################################
# Function:     display_i2c_scan_menu
# Purpose:      Display the options menu for i2c scan diagnostic
# Parameters:    none
# Returns:      none
######################################################################
display_i2c_scan_menu()
{
    do_local_echo "$PRODUCT_NAME I2C Diagnostic"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "M) Main-board I2C Scan Test"
    do_local_echo "A) Audio-board I2C Scan Test"
    do_local_echo "C) Conn-board I2C Scan Test"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "X) Exit"
}


######################################################################
# Function:     do_i2c_scan
# Purpose:      Scan the board that operator has selected, to watch whether 
#               all slave devices are in it. 
# Parameters:    board name - one of
#                   I2CBUS_MAIN_BOARD  - contain i2c bus 1
#                   I2CBUS_AUDIO_BOARD - contain i2c bus 2
#                   I2CBUS_CONN_BOARD  - contain i2c bus 3
# Returns:      none
######################################################################
do_i2c_scan()
{
    local board_name=`get_board_name_from_mode_id $1`
    local RETVAL

    case "$1" in
        $I2CBUS_MAIN_BOARD)
            do_local_echo "do i2cscan main board"
            slave_dev_name=`get_slave_dev_name $1 $I2C1_PMIC_ADDR`
            print_ret=`"$DIAG_TOOL_ROOT/i2cscan" $I2CBUS_MAIN_BOARD $I2C1_PMIC_ADDR`
            RETVAL=$?
            if [ "$RETVAL" -eq 0 ]; then
                success "I2C Scan $board_name $slave_dev_name Diagnostic"
            else
			    failure "I2C Scan $board_name $slave_dev_name Diagnostic"
            fi
            ;;
        $I2CBUS_AUDIO_BOARD)
            do_local_echo "do i2cscan audio board"

            for I2C2_ADDR in $I2C2_ADDR_LIST; do
                slave_dev_name=`get_slave_dev_name $1 $I2C2_ADDR`
                print_ret=`"$DIAG_TOOL_ROOT/i2cscan" $I2CBUS_AUDIO_BOARD $I2C2_ADDR`
                RETVAL=$?
                if [ "$RETVAL" -eq 0 ]; then
                    success "I2C Scan $board_name $slave_dev_name Diagnostic"
                else
                    failure "I2C Scan $board_name $slave_dev_name Diagnostic"
                fi
            done
            ;;
        $I2CBUS_CONN_BOARD)
            do_local_echo "do i2c_scan connector board"
            slave_dev_name=`get_slave_dev_name $1 $I2C3_DAC_ADDR`
            print_ret=`"$DIAG_TOOL_ROOT/i2cscan" $I2CBUS_CONN_BOARD $I2C3_DAC_ADDR`
            RETVAL=$?
            if [ "$RETVAL" -eq 0 ]; then
                success "I2C Scan $board_name $slave_dev_name Diagnostic"
            else
                failure "I2C Scan $board_name $slave_dev_name Diagnostic"
            fi
            ;;
        *)
            vmsg "Unknown board"
            ;;
	esac
}


######################################################################
# Function:     i2c_scan_do_run_diag
# Purpose:      Main routine for running i2c scan diagnostic. It displays
#               the main i2c scan diagnostic menu and runs any i2c scan
#               sub-diagnostic tests based on operator request.
#               The menu contains items for the following:
#                   1) Main-board I2C Scan Test
#					2) Audio-board I2C Scan Test
#					3) Conn-board I2C Scan Test
# Parameters:    none
# Returns:      none
######################################################################
i2c_scan_do_run_diag()
{
    # vmsg "i2c_scan_do_run_diag()"

    #
    # Get the requested test from user
    #
    local DONT_REDRAW_MENU=0
    local DO_EXIT=0
	local RETVAL
	
    while [ $DO_EXIT -ne 1 ]; do
	
	    if [ $DONT_REDRAW_MENU -eq 0 ]; then
            display_i2c_scan_menu
        else
            # DONT_REDRAW_MENU is a one-shot, so reset it now
            DONT_REDRAW_MENU=0
		fi
	
        local KEY=`get_char`
        RETVAL=$?
        do_local_echo
        if [ $RETVAL -eq 0 ]; then
            case "$KEY" in
                m | M)
				    vmsg "Starting Main-board I2C Scan Test..."
					do_local_echo "Main-board I2C Scan Test selected"
				    do_i2c_scan $I2CBUS_MAIN_BOARD
                    ;;
                a | A)
				    vmsg "Starting Audio-board I2C Scan Test..."
					do_local_echo "Audio-board I2C Scan Test selected"
				    do_i2c_scan $I2CBUS_AUDIO_BOARD
                    ;;
				c | C)
				    vmsg "Starting Conn-board I2C Scan Test..."
					do_local_echo "Conn-board I2C Scan Test selected"
				    do_i2c_scan $I2CBUS_CONN_BOARD
                    ;;
				x | X)
				    DO_EXIT=1
                    ;;
                *)
                    ;;
            esac	
        fi
    done
}


case "$1" in

    stop)
        vmsg "Exiting I2C Scan Diagnostic Test"
        return 0
        ;;

    start|*)
		vmsg "Starting I2C Scan Diagnostic Test"
		enter_diag "I2C Scan"
		# Clear any previous diagnostic test results
		clear_diag_fail
		i2c_scan_hal_init
		i2c_scan_do_run_diag
		i2c_scan_hal_exit
		exit_diag "I2C Scan" 0
		did_diag_fail
		test_failed="$?"
		return $test_failed
        ;;

esac
