#!/bin/sh
######################################################################
#
#  File:   wifi_diag.sh
#
#  Author: Xuyuda.YD.Xu
#
#  Date:   08/06/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the WIFI diagnostic.
#
#   Constants
#
#   Routines   
#
######################################################################


# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# WIFI HAL Functions
[ -f ${_WIFI_HAL_FUNCTIONS} ] && . ${_WIFI_HAL_FUNCTIONS}

# BT HAL Functions
[ -f ${_BT_HAL_FUNCTIONS} ] && . ${_BT_HAL_FUNCTIONS}

case "$1" in

    stop)
        vmsg "Exiting WIFI Diagnostic Test"
        ;;

    cycle)
        vmsg "Starting WIFI Diagnostic Cycle Test"
        ;;

    utilities)
        vmsg "Starting Utilities WIFI Diagnostic Test"
        enter_diag "WIFI Utilities"
        # Clear any previous diagnostic test results
        clear_diag_fail
        wifi_hal_init
	    if [ "$?" -ne 0 ]; then
			echo "wifi hal init failed"
	    else
            do_wifi_utilities_test
	    fi
        wifi_hal_exit
        exit_diag "WIFI Utilities" 0 0
        ;;
		
	pancake)
		vmsg "Starting Pancake WIFI Diagnostic Test"
		enter_diag "Pancake WIFI"
        # Clear any previous diagnostic test results
        clear_diag_fail
        wifi_hal_init
	    if [ "$?" -ne 0 ]; then
			echo "wifi hal init failed"
	    else
            pancake_wifi_utilities_test
	    fi
        wifi_hal_exit
        exit_diag "Pancake WIFI" 0 0
		;;
		
	vni)
        vmsg "Starting VnI WIFI Diagnostic Test"
        
        if [ $# -eq 2 ]; then
        	test_mode=$2
        fi
        
        enter_diag "WIFI VnI"
        # Clear any previous diagnostic test results
        clear_diag_fail
        wifi_hal_init
        res="$?"
	    if [ "$res" -ne 0 ]; then
			echo "wifi_hal_init() failure"
	    else
            do_wifi_VnI_test $test_mode
	    fi
        ## No need the wifi_hal_exit function for wifi VnI test
        exit_diag "WIFI VnI" 0 0     	
     	;;
     	
     *)
     	vmsg "error"
     	;;

esac
