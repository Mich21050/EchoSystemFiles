#!/bin/sh
######################################################################
#
#  File:   button_diag.sh
#
#  Author: Frank.Yi
#
#  Date:   2012.7.27
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the button diagnostic.
#
#   Routines
#	button_diag_display_menu()	-Display the main button diagnostic menu
#	do_run_button_diag()        - Run the button diagnostic
#
######################################################################

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# Button HAL Functions
[ -f ${_BUTTON_HAL_FUNCTIONS} ] && . ${_BUTTON_HAL_FUNCTIONS}

######################################################################
# Function:     button_diag_display_menu()
# Purpose:      Display the main button diagnostic menu.
# Parameters:    none
# Returns:      none
######################################################################
button_diag_display_menu()
{
    banner="$PRODUCT_NAME Button Diagnostic"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"
    do_local_echo "A) MICROPHONE-MUTE"
    do_local_echo "B) Alexa"
    #do_local_echo "C) WPS"
    do_local_echo "D) VOL+"
    do_local_echo "E) VOL-"
    do_local_echo "F) RESET"
    do_local_echo "$base"
    do_local_echo "X) Exit"
}

######################################################################
# Function:    do_run_button_diag
# Purpose:	   Display button diagnostic menu and ask the operator
#              testing each button
# Parameters:   none
# Returns:     none
######################################################################
do_run_button_diag()
{
    local DO_RETURN=0
    local DONT_REDRAW_MENU=0
    local key

    while [ $DO_RETURN -ne 1 ]; do
		if [ $DONT_REDRAW_MENU -eq 0 ]; then
		    button_diag_display_menu
		else
		    DONT_REDRAW_MENU=0
		fi
	
		key=`get_char`
		do_local_echo 
		case "$key" in
			A | a)
				do_test_button $MUTE
				;;

			B | b)
				do_test_button $ALEXA
				;;

			#C | c)
			#	do_test_button $WPS
			#	;;

			D | d)
				do_test_button $VOL_UP
				;;

			E | e)
				do_test_button $VOL_DOWN
				;;

			F | f)
				run_reset_button_diag
				;;

			X | x)
				DO_RETURN=1
				;;

			* )
				DONT_REDRAW_MENU=1
				;;
		esac
	done
}


case "$1" in

    stop)
        vmsg "Exiting Button Diagnostic"
	    button_hal_exit
        ;;

    start|*)
        vmsg "Displaying Button Diagnostic Services Menu."
        enter_diag "Button"
        # Clear any previous diagnostic test results
        clear_diag_fail
        button_hal_init
        RETVAL=$?
        if [ "$RETVAL" -eq 0 ]; then
            do_run_button_diag
        fi
        exit_diag "Button" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        ;;
esac
