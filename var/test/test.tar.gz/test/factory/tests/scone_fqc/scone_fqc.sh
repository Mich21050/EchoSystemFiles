#!/bin/sh

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

export BT_CONNECTION_STATUS="disconnected"
export SCONE_BT_MAC=

bt_wait_key()
{
    local arg1 arg2 arg3 arg4 KEY DONE

    arg1=$1
    if [ $# -ge 2 ];then
        arg2=$2
    else
        arg2="XX"	## a no use key
    fi

    if [ $# -ge 3 ];then
        arg3=$3
    else
        arg3="XX"	## a no use key
    fi

    if [ $# -ge 4 ];then
        arg4=$4
    else
        arg4="XX"	## a no use key
    fi

    DONE=0
    while [ $DONE -eq 0 ]; do
        KEY=`get_char`
        if [ "X$arg1" = "X$KEY" -o "X$arg2" = "X$KEY" ]; then
            DONE=1
        fi
        if [ "X$arg3" = "X$KEY" -o "X$arg4" = "X$KEY" ]; then
            DONE=2
        fi
    done
    echo ""
    return $DONE
}

fqc_show_menu()
{
    do_local_echo "Doppler & Scone FQC Test"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "A) BTConnect"
    do_local_echo "B) Check BTConnect"
    do_local_echo "C) Button&Reliability Test"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "X) Exit"
}

voice_power_on_bt()
{
    do_local_echo "Power on BT..."
    cp /lib/firmware/ar3k/1020201/PS_ASIC-Scone.pst	 /lib/firmware/ar3k/1020201/PS_ASIC.pst
    sync
    if [ "`hciconfig | grep hci0`" = "" ];then
        /usr/sbin/hciattach /dev/ttyO2 ath3k 3000000
        sleep 3

        if [ "`hciconfig | grep hci0`" = "" ];then
            failure "Power on BT failed"
            export BT_CONNECTION_STATUS="disconnected"
            return 1
        fi
    fi

    success "Power on BT successful"
    return 0
}

bt_connect()
{
    local voice_pid
    local scone_btmac
    local btmac_length
    local status

    echo -n "Enter Scone BT MAC : "
    read scone_btmac

    btmac_length=`echo ${#scone_btmac}`
    if [ $btmac_length -eq 0 ];then
        do_local_echo "user cancelled"
        return 1
    fi
    if [ $btmac_length -ne 17 ];then
        do_local_echo "Illegal mac address"
        return 1
    fi
    voice_power_on_bt
    if [ $? -ne 0 ];then
        return 1
    fi

    killall bluetoothd
    rm -rf /var/local/lib/bluetooth
    sleep 1
    /usr/sbin/bluetoothd -d
    sleep 3
    /usr/sbin/hciconfig hci0 voice 0x3
    sleep 2
    /usr/bin/bluez-simple-agent hci0 $scone_btmac
    status=$?
    sleep 1
    /usr/bin/bluez-test-device trusted $scone_btmac yes
    sleep 2

    if [ $status -ne 0 ];then
        failure "Connect to Scone($scone_btmac) failed"
        return 1
    fi

    export SCONE_BT_MAC=$scone_btmac

    success "Connect to Scone($SCONE_BT_MAC) successful"
}
check_bt_connect()
{
    if [ "`hcitool con | grep ${SCONE_BT_MAC}`" = "" ];then
        failure "Connect to Scone($SCONE_BT_MAC) failed"
        export BT_CONNECTION_STATUS="disconnected"
        return 1
    else
        success "Connect to Scone($SCONE_BT_MAC) successful"
        export BT_CONNECTION_STATUS="connected"
        return 0
    fi
}

button_scone_rel_test()
{
    local voice_pid remoted_tool_dir
    if [ -z ${SCONE_BT_MAC} ];then
        do_local_echo "Not connected to Scone"
        return 1
    fi
    if [ "`hcitool con | grep ${SCONE_BT_MAC}`" != "" ];then
        do_local_echo "Ready for Button&Reliability Test"
        /usr/local/bin/remoted -a ${SCONE_BT_MAC} -f /tmp/audio.wav -c /usr/local/share/button-test.cfg &
        voice_pid=$!
        do_local_echo "You can start your test now"
        do_local_echo "Press Q to exit"
        bt_wait_key Q q F f
        kill -9 $voice_pid
        if [ -f /tmp/audio.wav ];then
		rm /tmp/audio.wav
        fi
        return 0
    else
        do_local_echo "Not connected to Scone"
        return 1
    fi
}

run_scone_fqc_test()
{
    local DO_RETURN=0
    local DONT_REDRAW_MENU=0
    local key

    while [ $DO_RETURN -ne 1 ]; do
        if [ $DONT_REDRAW_MENU -eq 0 ]; then
            fqc_show_menu
        else
            DONT_REDRAW_MENU=0
        fi
        key=`get_char`
        do_local_echo
        case "$key" in
            A | a )
                bt_connect
            ;;
            B | b )
                check_bt_connect
            ;;
            C | c )
                button_scone_rel_test
            ;;
            X | x )
                DO_RETURN=1
            ;;
            * )
                DONT_REDRAW_MENU=0
            ;;
        esac
    done
}

case "$1" in

    start|*)
        enter_diag "Doppler & Scone FQC"
        # Clear any previous diagnostic test results
        clear_diag_fail
        run_scone_fqc_test
        exit_diag "Doppler & Scone FQC" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        ;;
esac
