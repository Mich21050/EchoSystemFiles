#!/bin/sh
######################################################################
#
#  File:   sdram_diag.sh
#
#  Author: Rich Wang
#
#  Date:   08/08/2012
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      This is the ddr ram diagnostic test.
#
#
#  Routines:
#      sdram_do_run_diag   -  Main routine for running sdram diagnostic
#
######################################################################

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# Sdram HAL Functions
[ -f ${_SDRAM_HAL_FUNCTIONS} ] && . ${_SDRAM_HAL_FUNCTIONS}

case "$1" in

    stop)
        vmsg "Exiting SDRAM Diagnostic Test"
        return 0
        ;;

    start|*)
        vmsg "Starting SDRAM Diagnostic Test"
        enter_diag "SDRAM"
        # Clear any previous diagnostic test results
        clear_diag_fail
        sdram_hal_init
		sdram_do_run_diag
				
        sdram_hal_exit 
        exit_diag "SDRAM" 0 0
#        did_diag_fail
#        test_failed="$?"
#        return $test_failed
        ;;

esac
