#!/bin/sh
######################################################################
#
#  File:   audio_diag.sh
#
#  Author: Linda Ru 
#
#  Date:   07/5/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the audio diagnostic.
#
#   Constants
#       DEFAULT_VOLUME              - Default output volume for audio tests
#       CHANNEL_SPEAKER_LEFT        - Left speaker channel
#       CHANNEL_SPEAKER_RIGHT       - Right speaker channel
#       CHANNEL_SPEAKER_STEREO      - Stereo speaker channel
#
#   Routines
#       audio_diag_display_menu()           - Display main audio diagnostic menu
#       show_hal_init_failure_message()     - Tell user about audio feature failure
#       audio_do_run_diag()                 - Display main audio diagnost menu, service test requests
#       do_run_mic_diag()                   - Test mic diag
#       run_line_out_diag()                 - Test line-out diag
######################################################################

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# Sound HAL Functions
[ -f ${_AUDIO_HAL_FUNCTIONS} ] && . ${_AUDIO_HAL_FUNCTIONS}

# Operator HAL Functions

[ -f ${_OPERATOR_HAL_FUNCTIONS} ] &&. ${_OPERATOR_HAL_FUNCTIONS}

export transfer_sound_files=0

######################################################################
# Function:     audio_diag_display_menu
# Purpose:      Display the main audio diagnostic menu.
# Parameters:    none
# Returns:      none
######################################################################
audio_diag_display_menu()
{
    banner="$PRODUCT_NAME Audio Test"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"
    
    do_local_echo "A) Speaker left and right channel"
    do_local_echo "B) Microphone Performance Test"
    do_local_echo "C) Audio ADC Calibration"
#    do_local_echo "D) Transfer 7 record wav files"
#    do_local_echo "E) Speaker left channel"
#    do_local_echo "F) Speaker right channel"
#    do_local_echo "D) Microphone Performance Test(3.0)"
#    do_local_echo "E) Failure Speaker Retest"
#    do_local_echo "F) Failure Microphone Retest"
    do_local_echo "$base"
    do_local_echo "X) Exit"
}


######################################################################
# Function:     show_hal_init_failure_message
# Purpose:      Show user why the audio hal failed to initialize
# Parameters:   reason - number representing reason for failure 
#               One of:
#                 AUDIO_APLAY_TOOL_BROKEN - Audio Play tool is missing/broken
#                 AUDIO_AMIXER_TOOL_BROKEN - Audio Mixer tool broken/missing
#                 AUDIO_ARECORD_TOOL_BROKEN - Audio Record tool broken/missing
# Returns:      none
# Side Effect:  Displays dialog, waits for user to respond before returning
######################################################################
show_hal_init_failure_message()
{
#    FAILURE_REASON="$1"

    do_local_echo "Audio Diagnostic Services Failure"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "Audio diagnostics failed to load because"
    case "$1" in
    	$AUDIO_APLAY_TOOL_BROKEN)
            do_local_echo "the audio play tool is missing/broken."
            ;;
            
        $AUDIO_AMIXER_TOOL_BROKEN)
            do_local_echo "the audio mixer tool is missing/broken."
            ;;
        
        $AUDIO_ARECORD_TOOL_BROKEN)
            do_local_echo "the audio record tool is missing/broken."
            ;;
           
        $AUDIO_WRITER_TOOL_BROKEN)
            do_local_echo "the audio wav-writer tool is missing/broken."
            ;;
           
        $MIC_CHECK_TOOL_BROKEN)
            do_local_echo "the audio mic-check tool is missing/broken."
            ;;    
              
        *)
            do_local_echo "an unknown error."
            ;;
    esac
    do_local_echo "Press $EXIT_KEY_LABEL to exit audio diagnostics."
    wait_for_console_key $EXIT_KEY
}


######################################################################
# Function:     do_run_mic_diag
# Purpose:      record wav file and save wav file,test mic function       
# Parameters:    mic number 
# Returns:      none
######################################################################
do_run_mic_diag()
{
    local number RETVAL TIME
	number=$1   
	if [ ${number} -eq 1 ];then
		vmsg "start test mic..."
		read -p "Please input the duration you want to record[0-10]:" TIME
		audio_mic_display_menu ${number}
		record_save_wav2 ${number} ${TIME}	 	
		RETVAL=$?		
		if [ ${RETVAL} -eq 0 ];then	 					    
		  	success "Microphone Performance test"
		else
		    do_local_echo "Record function failed"
			failure "Microphone Performance test"	
		fi	   
	fi
	
	if [ ${number} -eq 2 ];then
		audio_adc_calibration
	fi
	if [ ${number} -eq 3 ];then
	    vmsg "start test mic..."
		audio_mic_display_menu 1
		record_save_wav 4
		RETVAL=$?		
		if [ ${RETVAL} -eq 0 ];then	 					    
		  	success "Microphone Performance test"
		else
		    do_local_echo "Record function failed"
			failure "Microphone Performance test"	
		fi			
	fi
}

failure_speaker_retest()
{
    local RETVAL
    do_local_echo "Speaker failure retest ..."
    set_volume_out $SOUNDCHECK_VOLUME
    do_local_echo "Start playing wav file ..."
    sleep 2
    ${APLAY_TOOL} -Dplughw:0,1 ${STEREO_AUDIO_FILE} > /dev/null 2>&1
    RETVAL=$?
    sync
    if [ $RETVAL -eq 0 ];then
        success "Speaker Retest"
    else
        failure "Speaker Retest"
    fi
    return $RETVAL
}

failure_microphone_retest()
{
    local RETVAL
    do_local_echo "Microphone failure retest ..."
    rm -rf $DEFAULT_MIC_RECORD_FILE_PATH/*
    sync
    audio_mic_display_menu 1
    record_save_wav 1
    RETVAL=$?
    sync
    if [ ${RETVAL} -eq 0 ];then
        success "Microphone Retest"
    else
        do_local_echo "Record function failed"
        failure "Microphone Retest"
        return $RETVAL
    fi
    do_local_echo "Press Q to transfer wav files"
    wait_for_console_key Q q
    do_local_echo "Start transfer wav files ..."
    sleep 2
    wav_file_transfer7
    sync
    rm -rf $DEFAULT_MIC_RECORD_FILE_PATH/*
    sync
    do_local_echo "Done"
    return $RETVAL
}

######################################################################
# Function:     audio_do_run_diag()
# Purpose:      Display the main audio diagnostic menu, field operator
#               requests and run any sub-test requests.
# Parameters:    none
# Returns:      none
# Side Effect:  SUB_TEST_PASS is cleared on a failure
######################################################################
audio_do_run_diag()
{
    local DO_RETURN DONT_REDRAW_MENU KEY INSERT
    DO_RETURN=0
    DONT_REDRAW_MENU=0
	
  while [ $DO_RETURN -ne 1 ]; do

    # Put up the splash screen if we're manually starting up the framework.
    #
    if [ $DONT_REDRAW_MENU -eq 0 ]; then
        audio_diag_display_menu
    else
        # DONT_REDRAW_MENU is a one-shot, so reset it now
        DONT_REDRAW_MENU=0
    fi
 
    #
    # Get the key request
    #
    KEY=`get_char 2`
    echo
#    KEY=`get_char`
    if [ -z $KEY ];then
        DONT_REDRAW_MENU=0
    fi
    #
    # Process key request
    case "$KEY" in
       
    a | A)
        # Audio Speaker STEREO Channel Test...
        if ! [ -e /tmp/audio_A_done ];then
			#sleep 2
			touch /tmp/audio_A_done
			read -p "please input both channel volume[0-175]:" vm
			if [ -e /tmp/record/record.7.wav -a $transfer_sound_files -eq 2 ];then
				do_run_speaker_diag ${vm} ${SPEAK_SIM_FILE_PATH} &
				wav_file_transfer5
            elif [ -e /tmp/record/record.7.wav -a $transfer_sound_files -eq 0 ];then
				do_run_speaker_diag ${vm} ${SPEAK_SIM_FILE_PATH} &
				wav_file_transfer7
			else
				do_run_speaker_diag ${vm} ${SPEAK_SIM_FILE_PATH} &
			fi
		else
			read -p "please input both channel volume[0-175]:" vm
			do_run_speaker_diag ${vm} ${SPEAK_SIM_FILE_PATH} &
			#if [ -e /tmp/record/record.7.wav -a $transfer_sound_files -eq 0 ];then
			#	wav_file_transfer7
			#fi
        fi
		
		# for new audio test flow date:2015/07/01
		#read -p "please input both channel volume[0-175]:" vm
		#do_run_speaker_diag ${vm} ${SPEAK_SIM_FILE_PATH} 
        ;;
        
    b | B)
   		# Mic performance test
        if ! [ -e /tmp/audio_B_done ];then
            touch /tmp/audio_B_done
		fi
		do_run_mic_diag 1
		wav_file_transfer
        ;;
        
	c | C)
        # Audio ADC Calibration
        do_run_mic_diag 2
        ;;
		
    d | D)
   		# Mic performance test
#        if ! [ -e /tmp/audio_D_done ];then
#        	touch /tmp/audio_D_done
#			do_run_mic_diag 3
#        fi
		
		#for new audio test flow date:2015/07/01
		if [ -e /tmp/record/record.7.wav -a $transfer_sound_files -eq 0 ];then
			wav_file_transfer7
		else 
			do_local_echo "wav files not exist, please press B record first ..."
		fi
        ;;

    f | F)
		read -p "please input the right channel volume[0-175]:" vm
		do_speaker_diag2 ${CHANNEL_SPEAKER_RIGHT} ${vm} ${SPEAK_RIGHT_FILE_PATH}
	;;
	
	x | X)
        vmsg "Exiting Audio Diagnostic Test..."
	    DO_RETURN=1
        ;;

    *)
        DONT_REDRAW_MENU=0
        ;;

    esac
  done

}

######################################################################
# Function:     run_line_out_diag
# Purpose:      Test line-out diag
# Parameters:    none
# Returns:      none
######################################################################
run_line_out_diag()
{
	# Line-out Speaker STEREO Channel Test...
	local volume=$1        
	do_run_line_out_diag ${volume} ${LINE_OUT_FILE_PATH}
          
}


case "$1" in

    stop)
        vmsg "Exiting Audio Diagnostic Tests"
        ;;

    start|*)
        vmsg "Displaying Audio Diagnostic Services Menu"
        enter_diag "Audio Test"
        # Clear any previous diagnostic test results
        clear_diag_fail
        audio_hal_init
        RETVAL=$?
        if [ "$RETVAL" -eq 0 ]; then
            audio_do_run_diag
        else
            show_hal_init_failure_message "$RETVAL"
        fi
        exit_diag "Audio Test" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        ;;
esac

	
