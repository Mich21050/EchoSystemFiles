#!/bin/sh
######################################################################
#
#  File:   bt_diag.sh
#
#  Author: Xuyuda.YD.Xu
#
#  Date:   08/06/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the Bluetooth diagnostic.
#
#   Constants
#     
#   Routines
#
######################################################################

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# WIFI HAL Functions
[ -f ${_WIFI_HAL_FUNCTIONS} ] && . ${_WIFI_HAL_FUNCTIONS}

# BT HAL Functions
[ -f ${_BT_HAL_FUNCTIONS} ] && . ${_BT_HAL_FUNCTIONS}


case "$1" in

    stop)
        vmsg "Exiting WAN Diagnostic Test"
        ;;

    cycle)
        ;;

    utilities)
        vmsg "Starting WAN Diagnostic Test"
        enter_diag "BT Utilities"
        # Clear any previous diagnostic test results
        clear_diag_fail
        bt_hal_init
        res="$?"
	    if [ "$res" -ne 0 ]; then
			echo "bt_hal_init() failure"
	    else
            do_bt_utilities_test
	    fi
        bt_hal_exit
        exit_diag "BT Utilities" 0 0
        ;;
      *)
     	vmsg "error"
     	;;
esac
