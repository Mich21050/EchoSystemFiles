#!/bin/sh

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

export BT_CONNECTION_STATUS="disconnected"
export SCONE_BT_MAC=

bt_wait_key()
{
    local arg1 arg2 arg3 arg4 KEY DONE

    arg1=$1
    if [ $# -ge 2 ];then
        arg2=$2
    else
        arg2="XX"     ## a no use key
    fi

    if [ $# -ge 3 ];then
        arg3=$3
    else
        arg3="XX"     ## a no use key
    fi

    if [ $# -ge 4 ];then
        arg4=$4
    else
        arg4="XX"     ## a no use key
    fi

    DONE=0
    while [ $DONE -eq 0 ]; do
        KEY=`get_char`
        if [ "X$arg1" = "X$KEY" -o "X$arg2" = "X$KEY" ]; then
            DONE=1
        fi
        if [ "X$arg3" = "X$KEY" -o "X$arg4" = "X$KEY" ]; then
            DONE=2
        fi
    done
    echo ""
    return $DONE
}

voice_show_menu()
{
    do_local_echo "Doppler & Scone Voice Test"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "A) BTConnect"
    do_local_echo "B) Mic1 Record"
    do_local_echo "C) Mic2 Record"
    do_local_echo "D) PUSH WAVE"
    do_local_echo "E) Check BTConnect"
#    do_local_echo "F) Clear Doppler Pair Information"
#    do_local_echo "G) Auto Connect to Scone"
#    do_local_echo "H) Reliability Test"
#    do_local_echo "R) Reboot"
    
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "X) Exit"
}

voice_power_on_bt()
{
    do_local_echo "Power on BT..."
    cp /lib/firmware/ar3k/1020201/PS_ASIC-Scone.pst   /lib/firmware/ar3k/1020201/PS_ASIC.pst
    sync
    if [ "`hciconfig | grep hci0`" = "" ];then
        /usr/sbin/hciattach /dev/ttyO2 ath3k 3000000
        sleep 3

        if [ "`hciconfig | grep hci0`" = "" ];then
            failure "Power on BT failed"
            export BT_CONNECTION_STATUS="disconnected"
            return 1
        fi
    fi

    success "Power on BT successful"
    return 0
}

bt_connect()
{
    local voice_pid
    local scone_btmac
    local btmac_length
    local status

    echo -n "Enter Scone BT MAC : "
    read scone_btmac

    btmac_length=`echo ${#scone_btmac}`
    if [ $btmac_length -eq 0 ];then
        do_local_echo "user cancelled"
        return 1
    fi
    if [ $btmac_length -ne 17 ];then
        do_local_echo "Illegal mac address"
        return 1
    fi
    voice_power_on_bt
    if [ $? -ne 0 ];then
        return 1
    fi

    killall bluetoothd
    rm -rf /var/local/lib/bluetooth
    sleep 1
    /usr/sbin/bluetoothd -d
    sleep 3
    /usr/sbin/hciconfig hci0 voice 0x3
    sleep 2
    /usr/bin/bluez-simple-agent hci0 $scone_btmac
    status=$?
    sleep 1
    /usr/bin/bluez-test-device trusted $scone_btmac yes
    sleep 2

    if [ $status -ne 0 ];then
        failure "Connect to Scone($scone_btmac) failed"
        return 1
    fi

    export SCONE_BT_MAC=$scone_btmac

    success "Connect to Scone($SCONE_BT_MAC) successful"
}

mic_record()
{
    local mic_num=$1
    local voice_pid

    if [ "X${BT_CONNECTION_STATUS}" == "Xdisconnected" ];then
        failure "BT not connected"
        return 1
    fi

    rm -rf /tmp/audio_${mic_num}.wav
    sync

    /usr/local/bin/remoted -f /tmp/audio_${mic_num}.wav -a $SCONE_BT_MAC  &
    voice_pid=$!

    do_local_echo "Ready for mic${mic_num} voice test"
    do_local_echo "Press X to return"
    bt_wait_key X x V v

    kill -9 $voice_pid
    sync
    if [ -e "/tmp/audio_${mic_num}.wav" ];then
        success "mic${mic_num} record"
    else
        failure "mic${mic_num} record"
    fi
}

#prepare_kill_sz()
#{
#    local sleep_time SAVEDSTTY sz_pid
#    SAVEDSTTY=`stty -g`
#    sleep_time=$1
#    sleep $sleep_time
#    sz_pid=`ps | grep sz -m 1 | awk '{print $1}'`
#    if [ -z $sz_pid ];then
#        stty $SAVEDSTTY
#        return 0
#    fi
#    kill -9 $sz_pid
#    stty $SAVEDSTTY
#    sleep 1
#    stty ospeed 115200
#    sleep 1
#    stty ispeed 115200
#    echo "tty back"
#}

push_wav_file()
{
    wav_file1="/tmp/audio_1.wav"
    wav_file2="/tmp/audio_2.wav"

    do_local_echo "disable BT connection"
    export BT_CONNECTION_STATUS="disconnected"
	export SCONE_BT_MAC=

    if [ -e $wav_file1 ] && [ -e $wav_file2 ];then
        do_local_echo "audio_1.wav and audio_2.wav detected"
        do_local_echo "Press Q to start transfer"
        bt_wait_key Q q V v
        if [ $? -eq 2 ];then
            do_local_echo "Transfer cancelled"
        elif [ $? -eq 1 ];then
            sz -s 921600 -h $wav_file1
            sz -s 921600 -h $wav_file2
            sync
            do_local_echo "Transfer finished"
        fi
        rm -rf $wav_file1
        rm -rf $wav_file2
        sync
        return 0
    fi

    if [ -e $wav_file1 ];then
        do_local_echo "audio_1.wav detected"
        do_local_echo "Press Q to start transfer"
        bt_wait_key Q q V v
        if [ $? -eq 2 ];then
            do_local_echo "Transfer cancelled"
        elif [ $? -eq 1 ];then
            sz -s 921600 -h $wav_file1
            sync
            do_local_echo "Transfer finished"
        fi
        rm -rf $wav_file1
        sync
        return 0
    fi

    if [ -e $wav_file2 ];then
        do_local_echo "audio_2.wav detected"
        do_local_echo "Press Q to start transfer"
        bt_wait_key Q q V v
        if [ $? -eq 2 ];then
            do_local_echo "Transfer cancelled"
        elif [ $? -eq 1 ];then
            sz -s 921600 -h $wav_file2
            sync
            do_local_echo "Transfer finished"
        fi
        rm -rf $wav_file2
        sync
        return 0
    fi

    do_local_echo "No voice file found"
    do_local_echo "Please run voice test first"
    return 1
    
}

clear_doppler_pairinfo()
{
    if [ -z ${SCONE_BT_MAC} ];then
       do_local_echo "Not connected to Scone"
       return 1
    fi
    if [ "`hcitool con | grep ${SCONE_BT_MAC}`" != "" ];then
        do_local_echo " Ready for Clear Doppler Pairinformation"
        /usr/bin/bluez-test-device remove ${SCONE_BT_MAC}
        killall bluetoothd
        sleep 1
        if [ "`hcitool con  | grep ${SCONE_BT_MAC}`" != "" ];then
            failure "Push file and Clear Doppler Pairinformation"
        else
            success "Push file and Clear Doppler Pairinformation"
            export SCONE_BT_MAC=
        fi
        return 0
    else
        do_local_echo "Not connected to Scone"
        return 1
    fi
}

auto_connect_scone()
{
    local pair_scone_info pair_scone_name pair_scone_btmac

    voice_power_on_bt
    if [ $? -ne 0 ];then
        return 1
    fi

    do_local_echo "Scanning ..."
    hcitool  scan | awk 'NR>=2{print $1}' | (while read line;do echo $line $(hcitool name $line);done)   >  scone.log
    cat scone.log
    pair_scone_info=`cat  scone.log | grep "Horse Battery"|sort -nrk 4| head -n 1`

    if [ -z "$pair_scone_info" ];then
        do_local_echo "No Scone Device Found!"
        return 1
    fi

    pair_scone_name=`echo $pair_scone_info | awk '{print $2}'`
    if [ "$pair_scone_name" = "Horse" ];then
        pair_scone_btmac=`echo $pair_scone_info | awk '{print $1}'`
    else
        do_local_echo "No Scone Device Found!"
        return 1
    fi

    if [ -z $pair_scone_btmac ];then
        do_local_echo "No Scone Device Found!"
        return 1
    fi

    /usr/sbin/bluetoothd -d
    sleep 1
    /usr/sbin/hciconfig hci0 voice 0x3
    sleep 1
    /usr/bin/bluez-simple-agent hci0 $pair_scone_btmac
    sleep 1
    /usr/bin/bluez-test-device trusted $pair_scone_btmac yes
    sleep 1
    /usr/bin/bluez-test-input connect $pair_scone_btmac yes
    sleep 1
    if [ "`hcitool con | grep ${pair_scone_btmac}`" = "" ];then
        failure "Connect to Scone($pair_scone_btmac) failed"
        return 1
    else
        success "Connect to Scone($pair_scone_btmac) successful"
        export SCONE_BT_MAC=$pair_scone_btmac
        return 0
    fi
}

check_bt_connect()
{
    if [ "`hcitool con | grep ${SCONE_BT_MAC}`" = "" ];then
        failure "Connect to Scone($SCONE_BT_MAC) failed"
        export BT_CONNECTION_STATUS="disconnected"
        return 1
    else
        success "Connect to Scone($SCONE_BT_MAC) successful"
        export BT_CONNECTION_STATUS="connected"
        return 0
    fi
}
scone_rel_test()
{
    local voice_pid remoted_tool_dir
#    remoted_tool_dir="/test/factory/tools"
#    chmod +x /usr/local/bin/remoted
#    sync
#    voice_power_on_bt
#    if [ $? -ne 0 ];then
#        return 1
#    fi

#    auto_connect_scone
    if [ -z ${SCONE_BT_MAC} ];then
        do_local_echo "Not connected to Scone"
        return 1
    fi
    if [ "`hcitool con | grep ${SCONE_BT_MAC}`" != "" ];then
        do_local_echo "Ready for Reliability Test"
        /usr/local/bin/remoted -a ${SCONE_BT_MAC} -f /tmp/audio.wav -c /usr/local/share/button-test.cfg &
        voice_pid=$!
        do_local_echo "You can start your test now"
        do_local_echo "Press Q to exit"
        bt_wait_key Q q V v
        kill -9 $voice_pid
        rm scone.log
        return 0
    else
        do_local_echo "Not connected to Scone"
        return 1
    fi
}

run_scone_voice_test()
{
    local DO_RETURN=0
    local DONT_REDRAW_MENU=0
    local key

    while [ $DO_RETURN -ne 1 ]; do
        if [ $DONT_REDRAW_MENU -eq 0 ]; then
            voice_show_menu
        else
            DONT_REDRAW_MENU=0
        fi
        key=`get_char`
        do_local_echo
        case "$key" in
            A | a )
                bt_connect
            ;;
            B | b )
                mic_record 1
            ;;
            C | c )
                mic_record 2
            ;;
            D | d )
                push_wav_file
            ;;
            E | e )
                check_bt_connect
            ;;
#           F | f )
#               clear_doppler_pairinfo
#           ;;
#            G | g )
#                auto_connect_scone
#            ;;
#            H | h )
#                scone_rel_test
#            ;;          
#            R | r )
#                reboot
#            ;;
            X | x )
                DO_RETURN=1
            ;;
            * )
                DONT_REDRAW_MENU=0
            ;;
        esac
    done
}

case "$1" in

    start|*)
        enter_diag "Doppler & Scone Voice"
        # Clear any previous diagnostic test results
        clear_diag_fail
        run_scone_voice_test
        exit_diag "Doppler & Scone Voice" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        ;;
esac

