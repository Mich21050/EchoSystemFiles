#!/bin/sh

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}

# WIFI HAL Functions
[ -f ${_SOFTWARE_UPDATE_HAL_FUNCTIONS} ] && . ${_SOFTWARE_UPDATE_HAL_FUNCTIONS}

# Device Settings HAL
[ -f ${_DEV_SETTINGS_HAL_FUNCTIONS} ] && . ${_DEV_SETTINGS_HAL_FUNCTIONS}


display_software_update_menu()
{
    banner="$PRODUCT_NAME software update Diags"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    
    do_local_echo "$banner"
    do_local_echo "$base"
    do_local_echo "I) isp"
    do_local_echo "D) swdl"
    do_local_echo "C) checkversion"
    do_local_echo "$base"
    do_local_echo "X) Exit"
}

run_software_update()
{
    local DO_EXIT=0
    local REDRAW_MENU=0
	local KEY_VALUE=
    
    while [ $DO_EXIT -ne 1 ];do
        if [ $REDRAW_MENU -eq 0 ];then
		    display_software_update_menu
        else
            REDRAW_MENU=0
        fi
        
        KEY_VALUE=`get_char`
        do_local_echo
        case $KEY_VALUE in
            i | I)
				# do_set_pcb_id ##  ISP now flash idme partition,pcbsn will be set after ISP passes.
				run_isp
            ;;
                
            d | D)
                run_swdl
            ;;
                
            c | C)
                check_swdl_version
            ;;
                
            x | X)
                DO_EXIT=1
            ;;
                
            *)
                REDRAW_MENU=1
            ;;
        esac
        
    done
}


case "$1" in

    stop)
        vmsg "Exiting soft update Diagnostic Test"
        ;;

    cycle)
        ;;

    start|*)
        vmsg "Starting software update"
        enter_diag "software update"
        clear_diag_fail
        software_update_hal_init
		if [ $? -ne 0 ];then
			return 1
		fi
        run_software_update
        software_update_hal_exit
        exit_diag "software update" 0
        ;;

esac
