#!/bin/sh

# Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}



dev_get_mac_address()
{
	local target=$1
	local get_mac=
        get_mac=`doppler-idme --key mfg.btmac`
		export DEVICE_BT_MAC_ADDRESS=$get_mac
    do_local_echo "BT MAC Address    : $DEVICE_BT_MAC_ADDRESS"
}
pairing_show_menu()
{
    do_local_echo "Doppler & Scone Pairing Test"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "A) Get_BTMAC"
    do_local_echo "B) Write_BTMAC"
    do_local_echo "C) Write_Linkkey"
    do_local_echo "D) Read_Remotevalue"
    do_local_echo "E) Update Specific Password"
    do_local_echo "F) Disabling Console Login"
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "X) Exit"
}


write_scone_bt_mac()
{
    local scone_btmac
    local btmac_length

    echo -n "Enter Scone BT MAC : "
    read scone_btmac

    btmac_length=`echo ${#scone_btmac}`
    if [ $btmac_length -eq 0 ];then
        do_local_echo "user cancelled"
        return 1
    fi
    if [ $btmac_length -ne 12 ];then
        do_local_echo "Illegal mac address"
        return 1
    fi
    doppler-idme --key mfg.remotemac --val "$scone_btmac" > /dev/null 2>&1
    local status="$?"
    local get_btmac=`doppler-idme --key mfg.remotemac`
    
    if [ $status -eq 0 -a "$scone_btmac" == "$get_btmac" ]; then
        success "Write Scone BTmac $scone_btmac"
    	return 0
    else
        faiure "Write Scone BTmac $scone_btmac"
    	return 1
    fi
   
}

write_doppler_linkkey()
{
    local doppler_linkkey
    local linkkey_length
    echo -n "Enter Doppler Linkkey : "
    read doppler_linkkey
    
    linkkey_length=`echo ${#doppler_linkkey}`
    if [ $linkkey_length -eq 0 ];then
        do_local_echo "user cancelled"
        return 1
    fi
    doppler-idme --key mfg.remotelinkkey --val "$doppler_linkkey" > /dev/null 2>&1
    local status="$?"
    local get_linkkey=`doppler-idme --key mfg.remotelinkkey`
    
    if [ $status -eq 0 -a "$doppler_linkkey" == "$get_linkkey" ]; then
        success "Write Doppler Linkkey $doppler_linkkey"
    	return 0
    else
        faiure "Write Doppler Linkkey $doppler_linkkey"
    	return 1
    fi
}

read_remote_value()
{
    do_local_echo "Read Remote Value :"
    doppler-idme | grep mfg.remote*
    success "Read Remote"
}

update_specific_password()
{  
    do_local_echo "Update Specific Password now"
    /usr/local/bin/set_password
    sync;sync
}

disable_console_login()
{
    local tmp_name1="z6:6:off:/sbin/sulogin"
    local tmp_name2="O:2345:respawn:/sbin/mingetty ttyO0"
    do_local_echo "Disable Console Login now"
    sed -i "s|$tmp_name1||" /etc/inittab
    sed -i "s|$tmp_name2||" /etc/inittab
    sync;sync
}

run_scone_pairing_test()
{
    local DO_RETURN=0
    local DONT_REDRAW_MENU=0
    local key

    while [ $DO_RETURN -ne 1 ]; do
        if [ $DONT_REDRAW_MENU -eq 0 ]; then
            pairing_show_menu
        else
            DONT_REDRAW_MENU=0
        fi
        key=`get_char`
        do_local_echo
        case "$key" in
            A | a )
                dev_get_mac_address 
            ;;
            B | b )
                write_scone_bt_mac
            ;;
            C | c )
                write_doppler_linkkey
            ;;
            D | d )
               read_remote_value
            ;;
            E | e )
               update_specific_password
            ;;
            F | f )
               disable_console_login
            ;;

            X | x )
                DO_RETURN=1
            ;;
            * )
                DONT_REDRAW_MENU=0
            ;;
        esac
    done
}

case "$1" in

    start|*)
        enter_diag "Doppler & Scone Pairing"
        # Clear any previous diagnostic test results
        clear_diag_fail
        run_scone_pairing_test
        exit_diag "Doppler & Scone Pairing" 0
        did_diag_fail
        diag_test_failed="$?"
        return $diag_test_failed
        ;;
esac
