#!/bin/sh
#############################################################################
#
#  File:   dev_settings.sh
#
#  Author: Dennis.JL.Li
#
#  Date:   07/19/2012
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains various device setting utilities.  While it's not
#    actually a diagnostic, it is used by the factory on the production
#    line to configure various HW and OS settings.
#
#   
#  Routines
#      gather_device_information()     - Gather device info from system
#      do_set_mac_address              - write mac address to flash
#      verify_user_wants_to_set_ids    - Verify operator to use serial port for input
#      do_run_dev_settings_diag        - Display main device settings menu, field requests
#	   display_dev_settings_menu	   - Display the device setting menu
#############################################################################


# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_DIAG_FUNCTIONS}
[ -f ${_WIFI_HAL_FUNCTIONS} ] && . ${_WIFI_HAL_FUNCTIONS}
[ -f ${_BT_HAL_FUNCTIONS} ] && . ${_BT_HAL_FUNCTIONS}

# Device Settings HAL
[ -f ${_DEV_SETTINGS_HAL_FUNCTIONS} ] && . ${_DEV_SETTINGS_HAL_FUNCTIONS}


######################################################################
# Function:     gather_device_information
# Purpose:      Gather up information about the device, including
#                   Device Serial Number --> DEVICE_SERIAL_NUMBER
#                   Device PCB Id ---------> DEVICE_PCB_ID    
#                   DEVICE_WIFI_MAC_ADDRESS ---> DEVICE_WIFI_MAC_ADDRESS
#					DEVICE_BT_MAC_ADDRESS ---> DEVICE_BT_MAC_ADDRESS
#                   DEVICE microphone calibration data ---> DEVICE_AUDIO_CAL0
#                               DEVICE_AUDIO_CAL1  DEVICE_AUDIO_CAL2
#                               DEVICE_AUDIO_CAL3  DEVICE_AUDIO_CAL4
#                               DEVICE_AUDIO_CAL5  DEVICE_AUDIO_CAL6 
# Parameters:    none
# Returns:      none
# Side Effect:  Loads up global variables noted above
######################################################################
gather_device_information()
{
	do_local_echo "Gathering device information."
	do_local_echo "this will take a few seconds......"
	dev_get_serial_number  # Load DEVICE_SERIAL_NUMBER
	# Mark at 1019. No need to get pcd id in device setting station.
    # dev_get_pcb_id  # load PCB ID
    dev_get_mac_address WIFI  # Get WIFI MAC Address
    dev_get_mac_address BT  # Get BT MAC Address
    dev_get_wifi_secret
    dev_get_apmac
    # Mark at 1019. NO need to get auido calibration value in device setting station.
    # dev_get_audio_cal 
    
    # Display device information now
    do_local_echo "Serial Number     : $DEVICE_SERIAL_NUMBER"
#    do_local_echo "      PCBA ID     : $DEVICE_PCB_ID"
	do_local_echo "WIFI MAC Address  : $DEVICE_WIFI_MAC_ADDRESS"
	do_local_echo "BT MAC Address    : $DEVICE_BT_MAC_ADDRESS"
	do_local_echo "WIFI SECRET       : $DEVICE_WIFI_SECRET"
	do_local_echo "APMAC             : $DEVICE_APMAC"
	
#	do_local_echo "calibration data0 : $DEVICE_AUDIO_CAL0"
#	do_local_echo "calibration data1 : $DEVICE_AUDIO_CAL1"
#	do_local_echo "calibration data2 : $DEVICE_AUDIO_CAL2"
#	do_local_echo "calibration data3 : $DEVICE_AUDIO_CAL3"
#	do_local_echo "calibration data4 : $DEVICE_AUDIO_CAL4"
#	do_local_echo "calibration data5 : $DEVICE_AUDIO_CAL5"
#	do_local_echo "calibration data6 : $DEVICE_AUDIO_CAL6"
}


######################################################################
# Function:     do_set_mac_address
# Purpose:      Tell the operator to set the MAC address now (they've
#               already been instructed to use serial-port only for this
#               operation).  Read MAC address from serial port input 
#               and store it off in flash
# Parameters:    target
#				WIFI - set the WIFI MAC address
#				BT 	 - set thdo_set_mac_address()e BT MAC address
# Returns:      1 - MAC address set
#               0 - MAC address not set
# Side Effect:  Sets MAC address in flash
######################################################################
do_set_mac_address()
{
    local RET=0
    local target=$1
	
    # Get input from user for device serial number
    if [ "$target" = "WIFI" ]; then
    	echo "DEVICE_WIFI_MAC_ADDRESS = $DEVICE_WIFI_MAC_ADDRESS"
    elif [ "$target" = "BT" ]; then
    	echo "DEVICE_BT_MAC_ADDRESS = $DEVICE_BT_MAC_ADDRESS"	
    fi
    
    echo -n "Enter device $target MAC address now (enter to cancel) : "
    read USER_DEVICE_MAC_ADDRESS
    
    if [ -n "$USER_DEVICE_MAC_ADDRESS" ]; then
    	## verify the MAC address come from scan bar. 0: success, 1: failure
    	verify_mac_address "$USER_DEVICE_MAC_ADDRESS"
    	
    	if [ $? -eq 0 ]; then
    		## write MAC address
	        dev_set_mac_address "$target" "$USER_DEVICE_MAC_ADDRESS"
			return 0
	    else
			echo "MAC address input error."
			failure "$target MAC address Setting"
			RET=1
		fi
    else
        echo "Not setting device MAC address - user cancelled."
        failure "$target MAC address Setting"
        RET=1
    fi
    echo ""
    return $RET
}


######################################################################
# Function:     do_set_audio_cal
# Purpose:      Tell the operator to set audio cal now (they've
#               already been instructed to use serial-port only for this
#               operation).  Read audio cal from serial port input 
#               and store it in flash
# Parameters:    none
# Returns:      1 - if the seven audio cal values are setted successfully.
#               0 - only one value is setted failed.
# Side Effect:  Sets audio cal in flash
######################################################################
do_set_audio_cal()
{
    local RET=0
	local count=0
	local val=
	
    while [ $count -lt 7 ]; do
        echo -n "Enter audio cal$count now : "
        read val
        if [ -n "$val" ]; then
            dev_set_audio_cal $count $val
            let RET+="$?"
        else
            do_local_echo "Not audio cal$count - user cancelled."
        fi
        
        let "count=count+1"
        echo ""
    done
    
    if [ $RET -lt 7 ]; then
        failure "Audio CAL Setting"
    else
        success "Audio CAL Setting"
    fi
    echo ""
}


######################################################################
# Function:     display_dev_settings_menu
# Purpose:      Display the device setting menu
# Parameters:    none
# Returns:      none
######################################################################
display_dev_settings_menu()
{
    banner="$PRODUCT_NAME Device Setting Diagnostics"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	do_local_echo "$banner"
	do_local_echo "$base"
	# Get device information now...
	gather_device_information
	
	do_local_echo "$base"
	
	do_local_echo "D) Set DSN ID"  # Set Serial Number Menu Item
#	do_local_echo "P) Set PCBA ID"  # Set PCBA ID Menu Item
	do_local_echo "W) Set WIFI MAC Address"  # Set WIFI MAC Address Menu Item
	do_local_echo "B) Set BT MAC Address"  # Set BT MAC Address Menu Item
#	do_local_echo "A) Set Audio CAL Values"  # Set Audio CAL Values
    do_local_echo "C) Set WIFI SECRET"  # Set WIFI SECRET Values
    do_local_echo "M) Set APMAC"  # Set APMAC Values
	do_local_echo "Q) Reboot"  # to exit device settings and reboot 
	
	do_local_echo "$base"
	
	do_local_echo "X) Exit"  # to exit device settings without rebooting.     
}


######################################################################
# Function:     do_run_dev_settings_diag
# Purpose:      Gather up system information, display it to the user,
#               and then display the device settings menu.
#               Field operator menu requests.
# Parameters:    none
# Returns:      0 - No reboot is requested
#               1 - Reboot is requested
######################################################################
do_run_dev_settings_diag()
{
    local RET=
    local DO_EXIT=0
    local REDRAW_MENU=0

    while [ $DO_EXIT -ne 1 ]; do
        if [ $REDRAW_MENU -eq 0 ]; then
            display_dev_settings_menu
        else
            REDRAW_MENU=0
        fi
        
        local KEY=`get_char`
        echo " "
        case "$KEY" in
        d | D)
            do_set_serial_number
            ;;

#        p | P)
#            do_set_pcb_id
#            ;;

        w | W)
            do_set_mac_address WIFI
            ;;

        b | B)
            do_set_mac_address BT
            ;;

#        a | A)
#            do_set_audio_cal
#            ;;
        c | C)
            do_set_wifi_secret
            ;;

        m | M)
            do_set_apmac
            ;;

        q | Q)
            DO_EXIT=1  # DO_EXIT=1 stoping the menu recyle and exiting this module.
            RET=1  ## pass on an parameter to system diags menu.
            ;;

        x | X)
            DO_EXIT=1
            RET=0
            ;;

        *)
            REDRAW_MENU=1
            ;;
        esac
    done
    return $RET
}

case "$1" in

    stop)
        vmsg "Exiting Device Settings Module"
        ;;

    cycle)
        vmsg "Cycle mode not supported by the Device Settings Module"
        return 0
        ;;

    start|*)
        do_local_echo "Starting Device Settings Module"
        enter_diag "Device Settings"
        # Clear any previous diagnostic test results
        clear_diag_fail
        
        dev_settings_hal_init
        do_run_dev_settings_diag
        _DONT_REBOOT_DEVICE="$?"
        dev_settings_hal_exit
        
        exit_diag "Device Settings" 0 ${_DONT_REBOOT_DEVICE}
        ;;

esac
