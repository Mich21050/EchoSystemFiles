#!/bin/sh
##################################################################################
#
#  File:   system_diags.sh
#
#  Author: Xuyuda.YD.Xu
#
#  Date:   07/19/12
#
#  Copyright 2012, Ensky, Inc.  All rights reserved.
#
#  Description:
#      Contains the main system diagnostics engine.  This script is
#       responsible for determining which product we're on and then
#       setting up the environment for use with that product.  This
#       includes including the proper environment.productName file and
#       loading appropriate hals for the DUT where applicable.
#
#       This script displays the main system diagnostic's menu, and then
#       passed control the requested diagnostic test in the ./tests folder.
#
#   Important Constants
#       DIAGNOSTIC_ROOT         - Path to root of diagnostic tests
#       DIAG_TOOL_ROOT          - Path to root of diagnostic tools directory
#       DIAGNOSTIC_VERSION_FILE - Full path filename of diagnostic's version file
#		_Diag_Functions			- Diags common functions
#
#   Globals
#       LOG_OUTPUT_TO_LOGFILE   - 1 to log output to logfile, 0 to not.
#		OPERATOR_LOG_OUTPUT_TO_LOGFILE	- 1 to log output to $DIAGNOSTIC_OPERATOR_LOGFILE, 0 to not.
#		RUNIN_LOG_OUTPUT_TO_LOGFILE	- 1 to log output to $DIAGNOSTIC_RUNIN_LOGFILE
#       PASS                    - Set to 0 if a diagnostic fails
#       SUB_TEST_PASS           - Set to 0 if a diagnostic sub-test fails
#       DIAG_VERBOSE            - Verbosity level (0 or 1)
#
#   Routines
#       determine_platform()        - Determine which platform (product) we're on
#       get_sw_version()            - Get SW version from system
#       do_set_menu_item_keys()     - Dynamically set main menu items based on enabled tests
#       display_diag_result_summary - Display the diagnostic results summary
#       display_menu()              - Display the main system diagnostic's menu
#       display_user_disable_autorun_screen()   - Tell user how to re-enable diags
#       run_diagnostic_menu()       - Get and respond to user requests of main menu
#		run_diagnostic_misc_menu	- Sub-menu area for executing individual diagnostic tests
#		display_misc_menu			-  Display the misc system diagnostics menu.
#       run_utilities_menu			-  Sub-menu area for executing Utilities diagnostic tests.
#	    display_utilities_menu		-  Display the utilities test menu incuding WiFi BT test.
#		display_vni_menu			-  Display the VnI test menu.
#		run_vni_menu				-  Drives vni menu in misc individual diagnostics
#		display_ExitRbootDisable_menu	- 	Display the Exit,reboot,disable diags menu
#		return_sw_version			-  return diag and user filesystem sw. version
#		run_ExitRbootDisable_menu	-  Drives ExitRbootDisable module menu
#		display_dsn_pcbid_mainmenu	-  Display the dsn and pcbid above the main menu
#		disable_diags				-  Disable diagnostics
##################################################################################


# If this is a stop command, abort now, no need to continue (we
# save processing time from in-line gets of input driver entries
if [ "$1" == "stop" ]; then
    exit 0
fi


# Global Variables
export PASS=1			##<---this is the main test result flag
export SUB_TEST_PASS=1	##<---this is the sub test result flag

# Verbosity Level, open or close vmsg log
export DIAG_VERBOSE=0

#
# Set to 1 to output logs to a logfile
#
export LOG_OUTPUT_TO_LOGFILE=0
export OPERATOR_LOG_OUTPUT_TO_LOGFILE=0
export RUNIN_LOG_OUTPUT_TO_LOGFILE=0
export SAVE_RUNIN_ARG=0
export DO_LOCAL_ECHO_LOCK=1


# Important Locations on Target
DIAGS_ROOT="/test/factory"	## the diagnostics test files root
export DIAGNOSTIC_ROOT="$DIAGS_ROOT"	
export DIAG_TOOL_ROOT="$DIAGNOSTIC_ROOT/tools"	## test tools root
export DIAGNOSTIC_VERSION_FILE="$DIAGNOSTIC_ROOT/diags_version"	 ## diag version file
export _Diag_Functions="/test/factory/functions"	## diags common functions


# If a diags version file exists, source it now
if [ -f $DIAGNOSTIC_VERSION_FILE ]; then
    . "${DIAGNOSTIC_VERSION_FILE}"	
fi


#
# Determine which platform we're on first
#
## for Dpooler project
export DOPPLER_NAME="DOPPLER&PANCAKE"
export DOPPLER_SUFFIX="doppler"


#
# List of Possible Commonly Supported Diagnostic Modules
# All an environment.product file needs to do is define
# the components they have by setting it to a 1.  We will
# preset all to zero to allow product scripts to ONLY enable
# components that they have, and not have to worry about what
# they don't have.
#
export HAS_WIFI=0
export HAS_BT=0
export HAS_MOVINAND=0
export HAS_MEMORY=0
export HAS_LED=0
export HAS_BUTTONS=0
export HAS_VI=0
export HAS_POWER=0
export HAS_I2C_SCAN=0
export HAS_AUDIO=0
export HAS_511=0
export HAS_OPERATOR_SUITE=0
export HAS_RUN_MODES=0
export HAS_DEVICE_SETTINGS=0
export HAS_MISC=0
## add the new components as follow
## reserved...

### WIFI_NTF_DEBUG
export WIFI_NTF_DEBUG_ENABLE=0

if [ $WIFI_NTF_DEBUG_ENABLE -eq 1 ];then
    export WIFI_LOG_FILE="/test/wifi.log"
elif [ $WIFI_NTF_DEBUG_ENABLE -eq 0 ];then
    rm -rf /test/wifi.log
    sync
fi

######################################################################
# Function:     determine_platform
# Purpose:      Determine which device we're on.  FIrst look for the
#               usb device entry point to determine if we're Kindle
#               or not.  If we're not, then check board_id to determine
#               the device type.  If there's no board_id, or it's unknown,
#               display "diag failure" message.  Make user dismiss baord_id
#               failure message if it's an unrecognized id (i.e. if it's
#               NOT a Mario or ADS board_id, which is a valid ID, just
#               not supported by diags.
# Parameters:    none
# Returns:      0 - Board ID verified properly
#               1 - Board ID Verification Failed !
######################################################################
determine_platform()
{
	export PRODUCT="$DOPPLER_SUFFIX"
	export PRODUCT_NAME="$DOPPLER_NAME"
	
	local board_rev=`cat /proc/board_rev`
	
	if [ -z $board_rev ];then
		return 1
	fi
	
	case $board_rev in

		P_*)
		## pancake board
		export BOARD_NAME_ID=2
		;;

		*)
		## doppler board and default
		export BOARD_NAME_ID=1
		;;

	esac
	
    return 0
}


#
# Include environment variables, macros, location definitions, etc...
#
determine_platform      # Determine platform before defining environment vars
board_id_failed="$?"
if [ $board_id_failed -eq 1 ]; then
    # For now, we reboot on board_id verification failure (endless loop until board_id is fixed)
    reboot
fi


#
# Initialize and export product-specific environment variables
#
if [ -f $DIAGNOSTIC_ROOT/environment.$PRODUCT ]; then
    . "${DIAGNOSTIC_ROOT}/environment.${PRODUCT}"
else
    echo "ERROR - '$DIAGNOSTIC_ROOT/environment.$PRODUCT' not found."
    exit
fi


######################################################################
# Function:     display_user_disable_autorun_screen
# Purpose:      Tell user we've disabled diagnostics auto-run feature,
#               and explain how to re-enable it if they desire.
# Parameters:    autorun_disabled - 0 if disabling failed, 1 if we're disabled
# Returns:      none
######################################################################
display_user_disable_autorun_screen()
{
    AUTORUN_DISABLE_WORKED="$1"

    # Tell user what's going on and how to re-enable diags...
    do_local_echo "$PRODUCT_NAME Diagnostic Services" 
    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" 

    if [ $AUTORUN_DISABLE_WORKED -eq 1 ]; then
        do_local_echo "System diagnostics will no longer be"
        do_local_echo "executed automatically at boot."
        do_local_echo "To re-enable auto-boot, please input"
        do_local_echo "    idme bootmode diags;res"
        do_local_echo "in u-boot command line"
        do_local_echo "Rebooting the device now..."
    else
        do_local_echo "Disabling of the auto-boot feature failed."
        do_local_echo "Please enter the command 'doppler-idme --key bootmode'"
        do_local_echo "  to see the value of bootmode."
        do_local_echo "Press key x or X to continue."
        wait_for_console_key x X
    fi
}


##################################################################################
#
# Once we're here, we have determined we have a valid product and are pointing to
# the proper places to retrieve operator input.
# We will now initialize the proper environment variables files for this device.
# We can also include HALs now that we know which device we're on...
#
##################################################################################

#
# Initialize and export all environment variables
#
export EN_VARS="$DIAGNOSTIC_ROOT/environment.vars"
[ -f ${EN_VARS} ] && . ${EN_VARS}

# Include some Useful Diagnostic Functions
[ -f ${_DIAG_FUNCTIONS} ] && . ${_Diag_Functions}

# Include enable/disable_accessories_port
[ -f ${_POWER_HAL_FUNCTIONS} ] && . ${_POWER_HAL_FUNCTIONS}

# Include WIFI hal for wifi_511_test() call
[ -f ${_WIFI_HAL_FUNCTIONS} ] && . ${_WIFI_HAL_FUNCTIONS}

# Include DEVICE SETTINGS HAL
[ -f ${_DEV_SETTINGS_HAL_FUNCTIONS} ] && . ${_DEV_SETTINGS_HAL_FUNCTIONS}

# Include Run Modes HAL Functions
[ -f ${_RUN_MODES_HAL_FUNCTIONS} ] && . ${_RUN_MODES_HAL_FUNCTIONS}

# Sound HAL Functions
[ -f ${_AUDIO_HAL_FUNCTIONS} ] && . ${_AUDIO_HAL_FUNCTIONS}

# LED HAL Functions
[ -f ${_LED_HAL_FUNCTIONS} ] && . ${_LED_HAL_FUNCTIONS}

######################################################################
# Function:     get_sw_version
# Purpose:      Get the version of software on the device
# Parameters:    none
# Returns:      none
# Side Effect:  SOFTWARE_FS_VERSION is set to the filesystem version
#               SOFTWARE_FS_BUILD_DATE is set to the software build date
######################################################################
get_sw_version()
{
#	VERSION=`cat /etc/version.txt | grep "VERSION" | cut -d "=" -f2`
#	VER_DATE=`cat /etc/version.txt | grep "VER_DATE" | cut -d "=" -f2`
#    export DIAG_SOFTWARE_FS_VERSION="$VERSION"
#    export DIAG_SOFTWARE_FS_BUILD_DATE="$VER_DATE"
    export DIAG_SOFTWARE_FS_VERSION="$DIAGNOSTICS_VERSION"
    export DIAG_SOFTWARE_FS_BUILD_DATE="$DIAGNOSTICS_BUILD_DATE"
}


######################################################################
# Function:     display_dsn_pcbid_mainmenu
# Purpose:      Display the dsn and pcbid above the main menu
# Parameters:   none
# Returns:      none
######################################################################
display_dsn_pcbid_mainmenu()
{
	do_local_echo ""
	dev_get_serial_number
	dev_get_pcb_id
    do_local_echo "Serial Number     : $DEVICE_SERIAL_NUMBER"
    do_local_echo "      PCBA ID     : $DEVICE_PCB_ID"	
    do_local_echo ""	
}


######################################################################
# Function:     display_diag_result_summary
# Purpose:      Display a screen with an overall PASSED/FAILED analysis
#               of the system diagnostic results.  If ANY test failed,
#               we fail.
#
#               If no tests were run, we bypass this dialog.
#
#               Waits for user to hit EXIT_KEY before continuing/clearing
#               screen.
# Parameters:    none
# Returns:      none
######################################################################
display_diag_result_summary()
{
    DO_DISPLAY_SCREEN=0
    ##<---check the diag result from diag_results logfile
    ##<---0:test_pass, 1:test_fail; 2. can't find logfile
    did_system_diags_fail
    RETVAL=$?
    case "$RETVAL" in
        0)  # Diags Passed
            do_local_echo "PASSED"
            do_local_echo "System Diagnostic Tests Passed"
            ;;

        2)  # Diags were never run
            #do_local_echo "FAILED"
            do_local_echo "System Diagnostic Tests Were Never Run"
            ;;

        1|*)  # Diags Failed
            do_local_echo "FAILED"
            do_local_echo "System Diagnostic Tests Failed"
            ;;
    esac

    if [ $DO_DISPLAY_SCREEN -eq 1 ]; then
        banner="$PRODUCT_NAME Diagnostic Services, version  $DIAGNOSTICS_BUILD $DIAGNOSTICS_VERSION"
        base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        do_local_echo "$banner"
        do_local_echo "$base"
        do_local_echo "Press key x or X to continue."
        wait_for_console_key x X
    fi
}


######################################################################
# Function:     display_vni_menu
# Purpose:      Display the VnI test menu.
# Parameters:    none
# Returns:      none
######################################################################
display_vni_menu()
{
    banner="$PRODUCT_NAME VnI Diagnostic"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

    if [ -n "$HAS_BT" ] && [ $HAS_BT -eq 1 ]; then
        do_local_echo "A) BT RX-Continuous Test"
        do_local_echo "B) BT TX-Continuous Test"
        do_local_echo "C) BT OFF"
    fi

    if [ -n "$HAS_WIFI" ] && [ $HAS_WIFI -eq 1 ]; then
        do_local_echo "D) WIFI RX-Continuous Test"
        do_local_echo "E) WIFI TX-Continuous Test"
        do_local_echo "F) Wi-Fi Minimum-power State"
    fi
	

    if [ "x$HAS_POWER" == "x1" ]; then
        do_local_echo "G) Power Nominal mode"
    fi

    # All devices support exit
    do_local_echo "$base"
    do_local_echo "X) Exit"
}


######################################################################
# Function:     display_misc_menu
# Purpose:      Display the misc system diagnostics menu.  This menu
#               is built dynamically based on which diagnostic tests
#               are enabled for this product/platform (defined in
#               the environment.PRODUCT file).
# Parameters:    none
# Returns:      none
######################################################################
display_misc_menu()
{
 
    banner="$PRODUCT_NAME Misc Diagnostics"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    do_local_echo "$banner"
    do_local_echo "$base"

## These two items are the same as Utilities item. so we remove it
#	if [ "x$HAS_WIFI" == "x1" ]; then
#        do_local_echo "A) Wifi Test"
#    fi
#    
#    if [ "x$HAS_BT" == "x1" ]; then
#        do_local_echo "B) BT Test"
#    fi
    do_local_echo "A) ALS Test"
    do_local_echo "B) Bluetooth pcm loopback test"
    do_local_echo "C) LED Test"
    do_local_echo "D) Button Test"
    do_local_echo "E) Utilities"

## remove this item base on Test Coverage_v3.5	
#	if [ "x$HAS_VI" == "x1" ]; then
#		do_local_echo "F) VnI test"
#	fi
    do_local_echo "G) SDRAM Test"
    do_local_echo "H) I2C Scan Test"
	do_local_echo "M) Microphone Test"
	do_local_echo "S) Speaker left and right Test"
	do_local_echo "$base"
	do_local_echo "X) Exit"
}


######################################################################
# Function:     display_menu
# Purpose:      Display the main system diagnostics menu.  This menu
#               is built dynamically based on which diagnostic tests
#               are enabled for this product/platform (defined in
#               the environment.PRODUCT file).
# Parameters:    none
# Returns:      none
######################################################################
display_menu()
{
    banner="$PRODUCT_NAME Diagnostic Services version $DIAGNOSTICS_BUILD $DIAGNOSTICS_VERSION"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    
	## Display DSN and PCB ID for Product line request
	display_dsn_pcbid_mainmenu
	
    do_local_echo "$banner"
    do_local_echo "$base"

    if [ "x$HAS_DEVICE_SETTINGS" == "x1" ]; then
        do_local_echo "S) Device Setting"
    fi

    if [ "x$HAS_OPERATOR_SUITE" == "x1" ]; then
        do_local_echo "O) Operator Test Suite"
    fi

    if [ "x$HAS_RUN_IN" == "x1" ]; then
        do_local_echo "R) Run In Test"
    fi

    if [ "x$HAS_511" == "x1" ]; then
        do_local_echo "E) 511"
    fi

    if [ "x$HAS_POWER" == "x1" ]; then
        do_local_echo "T) Power Test"
    fi

    if [ "x$HAS_AUDIO" == "x1" ]; then
        do_local_echo "A) Audio Test"
    fi
    
   do_local_echo "M) RMA"
    ## misc individual test menu
    do_local_echo "N) Misc individual Test"

    ## exit reboot disable diags test menu
    do_local_echo "D) Exit, Reboot or Disable Diags"

    do_local_echo "V) Scone Voice Test"
    do_local_echo "F) Scone FQC   Test"
    do_local_echo "P) Pairing Process Test"
    do_local_echo "$base"
	
    # All devices support exit
    do_local_echo "X) Exit"
}


######################################################################
# Function:     run_vni_menu
# Purpose:      Drives vni menu in misc individual diagnostics
# Parameters:    none
# Returns:      none
######################################################################
run_vni_menu()
{
    DO_EXIT=0
    DONT_REDRAW_MENU=0
    
    do_local_echo "You enter into VnI test"

    while [ $DO_EXIT -ne 1 ]; do

        if [ $DONT_REDRAW_MENU -eq 0 ]; then
            display_vni_menu
        else
            # DONT_REDRAW_MENU is a one-shot, so reset it now
            DONT_REDRAW_MENU=0
        fi

        #
        # Get the key request
        #
        KEY=`get_char`
        echo " "
        
        #
        # Process key request
        case "$KEY" in
            
            a | A)
                vmsg "Starting BT RX-Continuous Test..."
                do_local_echo "BT RX-Continuous Test selected"
                if [ -n "$HAS_BT" ] && [ $HAS_BT -eq 1 ]; then
                    ${RUN_BT_RX_CONTINUOUS}
                fi
                ;;
                
            b | B)
                vmsg "Starting BT TX-Continuous Test..."
                do_local_echo "BT TX-Continuous Test selected"
                if [ -n "$HAS_BT" ] && [ $HAS_BT -eq 1 ]; then
                    ${RUN_BT_TX_CONTINUOUS}
                fi
                ;; 
                
            c | C)
                vmsg "You have power off BT Test..."
                do_local_echo "BT OFF selected"
                if [ -n "$HAS_BT" ] && [ $HAS_BT -eq 1 ]; then
                    ${RUN_BT_OFF}
                fi
                ;; 
                
            d | D)
                vmsg "Starting WIFI RX-Continuous Test..."
                do_local_echo "WIFI RX-Continuous Test selected"
                if [ -n "$HAS_WIFI" ] && [ $HAS_WIFI -eq 1 ]; then
                    ${RUN_WIFI_VNI} rx
                fi
                ;;
                
            e | E)
                vmsg "Starting WIFI TX-Continuous Test..."
                do_local_echo "WIFI TX-Continuous Test selected"
                if [ -n "$HAS_WIFI" ] && [ $HAS_WIFI -eq 1 ]; then
                    ${RUN_WIFI_VNI} tx
                fi
                ;;
                
            f | F)
                vmsg "You have power off WIFI Test..."
                do_local_echo "WIFI minimum-power state selected"
                if [ -n "$HAS_WIFI" ] && [ $HAS_WIFI -eq 1 ]; then
                    ${RUN_WIFI_VNI} stop
                fi
                ;;
                
            g | G)
                vmsg "Starting Power Nominal Mode Test..."
                do_local_echo "Power Nominal Mode selected"
                if [ -n "$HAS_POWER" ] && [ $HAS_POWER -eq 1 ]; then
                    do_run_power_in_vni_menu
                fi
                ;;
                
            x | X)
                vmsg "Exiting VnI Test..."
                do_local_echo "Exit VnI Test selected"
                DO_EXIT=1
                ;;
                
            *)
                ;;
        esac
    done
}


######################################################################
# Function:     display_utilities_menu
# Purpose:      Display the utilities test menu incuding WiFi BT test.
# Parameters:    none
# Returns:      none
######################################################################
display_utilities_menu()
{
	banner="$PRODUCT_NAME utilities Diagnostic"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    
	## Display DSN and PCB ID for Product line request
	## <---add at 0906. for PC tool requestment
	display_dsn_pcbid_mainmenu
	do_local_echo "$PRODUCT_NAME Diagnostic Services version $DIAGNOSTICS_BUILD $DIAGNOSTICS_VERSION"
	## --->add at 0906. for PC tool requestment
		   
    do_local_echo "$banner"
    do_local_echo "$base"
   
	do_local_echo "A) Doppler WiFi Test" ## Both wifi and BT tests are in this item.
	do_local_echo "B) BT Test"
	do_local_echo "C) BT-FATP-Test"
	do_local_echo "P) Pancake WiFi Test"
### WIFI_NTF_DEBUG
    if [ $WIFI_NTF_DEBUG_ENABLE -eq 1 ];then
        do_local_echo "R) Read WiFi NTF debug log file"
    fi
	
	do_local_echo "$base"
	do_local_echo "X) Exit"
}

### WIFI_NTF_DEBUG
read_wifi_ntf_debug_log()
{
    if [ $WIFI_NTF_DEBUG_ENABLE -eq 1 ];then
        do_local_echo "Log Start"
#        cat $WIFI_LOG_FILE
        do_local_echo "Log End"
        sleep 2
        sz -s 921600 -h $WIFI_LOG_FILE
        rm -rf $WIFI_LOG_FILE
        sync
    fi
    return 0
}

######################################################################
# Function:     run_utilities_menu
# Purpose:      Sub-menu area for executing Utilities diagnostic tests.
# Parameters:    none
# Returns:      none
######################################################################
run_utilities_menu()
{
	local DO_EXIT=0
	local DONT_REDRAW_MENU=0
	
	# Process user requests
	while [ $DO_EXIT -ne 1 ]; do
	
		# Put up utilities diagnostic menu
		#
		if [ $DONT_REDRAW_MENU -eq 0 ]; then
		    display_utilities_menu
		else
		    # DONT_REDRAW_MENU is a one-shot, so reset it now
		    DONT_REDRAW_MENU=0
		fi
		
		#
		# Get the key request
		#
		local KEY=`get_char`
		do_local_echo
		
		#
		# Process key request
		case "$KEY" in
		
		'A' | 'a')
		    vmsg "Starting Wifi Test..."
		    do_local_echo "Utilities: Wifi selected"
		    ${RUN_WIFI_UTILITIES}
		    ;;
		    
		'B' | 'b')
		    vmsg "Starting BT Test..."
		    do_local_echo "Utilities: BT selected"
		    ${RUN_BT_UTILITIES}
		    ;;
		    
		 'C' | 'c' )
		 	vmsg "Starting BT FATP Test..."
		 	do_local_echo "Utilities: BT FATP Test selected"
		 	run_bt_fatp_test
		 	;;

		'P' | 'p')
		 	do_local_echo "Starting Pancake WIFI Test..."
		 	${RUN_PANCAKE_WIFI}
		 	;;
### WIFI_NTF_DEBUG
        'R' | 'r')
            read_wifi_ntf_debug_log
            ;;
		
		'X' | 'x')
		    do_local_echo "MISC: Exit selected"
		    vmsg "Exiting back to main Diagnostic Services menu..."
		    DO_EXIT=1
		    ;;
		
		*)
		    DONT_REDRAW_MENU=1
		    ;;
		esac
	done;	
}


######################################################################
# Function:     run_diagnostic_misc_menu
# Purpose:      Sub-menu area for executing individual diagnostic tests
#               tests that are now part of the operator test suite
# Parameters:    none
# Returns:      none
######################################################################
run_diagnostic_misc_menu()
{
	local DO_EXIT=0
	local DONT_REDRAW_MENU=0
	
	# Process user requests
	while [ $DO_EXIT -ne 1 ]; do
	
		# Put up misc diagnostic menu
		#
		if [ $DONT_REDRAW_MENU -eq 0 ]; then
		    display_misc_menu
		else
		    # DONT_REDRAW_MENU is a one-shot, so reset it now
		    DONT_REDRAW_MENU=0
		fi
		
		#
		# Get the key request
		#
		local KEY=`get_char`
		do_local_echo
		
		#
		# Process key request
		case "$KEY" in

## These two items are the same as Utilities item. so we remove it		
#		'A' | 'a')
#		    vmsg "Starting Wifi Test..."
#		    do_local_echo "MISC: Wifi selected"
#		    ${RUN_WIFI_UTILITIES}
#		    ;;
#		'B' | 'b')
#		    vmsg "Starting BT Test..."
#		    do_local_echo "MISC: BT selected"
#		    ${RUN_BT_UTILITIES}
#		    ;;
		'A' | 'a')
		    vmsg "Starting ALS Test..."
		    do_local_echo "MISC: ALS selected"
		    ${RUN_ALS}
		    ;;
		'B' | 'b')
		    do_local_echo "Starting bluetooth pcm loopback test"
		    bt_pcm_loopback_test
		    ;;
		
		'C' | 'c')
		    vmsg "Starting LED Test..."
		    do_local_echo "MISC: LED Test selected"
		    ${RUN_LED}       
		    ;;
		
		'D' | 'd')
		    vmsg "Starting Button Test..."
		    do_local_echo "MISC: Button selected"
		    ${RUN_BUTTON}
		    ;;
		
		'E' | 'e')
		    vmsg "Starting utilities Test..."
		    do_local_echo "MISC: utilities selected"
		    run_utilities_menu
		    ;;

## remove this item base on Test Coverage_v3.5			
#		'F' | 'f')
#		    vmsg "Starting Vni Test..."
#		    do_local_echo "MISC: VNI Test selected"
#		    run_vni_menu
#		    ;;
		
		'G' | 'g')
		    vmsg "Starting SDRAM Test..."
		    do_local_echo "MISC: SDRAM test selected"
		    ${RUN_SDRAM}
		    ;;
		
		'H' | 'h')
		    vmsg "Staring I2C scan Test..."
		    do_local_echo "MISC: I2C scan test selected"
		    ${RUN_I2C_SCAN}
		    ;;
		    
		'M' | 'm')
		    vmsg "Microphone Test..."
		    do_local_echo "MISC: Microphone Test selected"
		    fct_mic_adc
		    ;;
		    
		'S' | 's')
		    vmsg "Speaker left and right Test..."
		    do_local_echo "MISC: Speaker left and right Test selected"
		    do_run_speaker_diag ${DEFAULT_VOLUME} ${FCT_AUDIO_FILE}
		    ;;
		
		'X' | 'x')
		    do_local_echo "MISC: Exit selected"
		    vmsg "Exiting back to main Diagnostic Services menu..."
		    DO_EXIT=1
		    ;;
		
		*)
		    DONT_REDRAW_MENU=1
		    ;;
		esac
	done
}


######################################################################
# Function:     display_ExitRbootDisable_menu
# Purpose:      Display the Exit,reboot,disable diags menu
# Parameters:    none
# Returns:      none
######################################################################
display_ExitRbootDisable_menu()
{
    banner="$PRODUCT_NAME Exit,Reboot or Disable Diags"
    base="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
    
    do_local_echo "$banner"
    do_local_echo "$base"
    do_local_echo "V) Return SW version"
    do_local_echo "U) MMC bundle install"
    do_local_echo "C) check PASS/FAIL status"
    do_local_echo "R) Reboot System"
    do_local_echo "D) Disable diagnostics"
    do_local_echo "$base"
    do_local_echo "X) Exit"    	
}


######################################################################
# Function:     return_sw_version
# Purpose:      return diag and user filesystem sw. version
# Parameters:    none
# Returns:      none
######################################################################
return_sw_version()
{ 
	do_local_echo "Diag FS Version: $DIAG_SOFTWARE_FS_VERSION"
	do_local_echo "Diag Build Date: $DIAG_SOFTWARE_FS_BUILD_DATE"
	
	if [ -n "$DIAG_SOFTWARE_FS_VERSION" -a -n "$DIAG_SOFTWARE_FS_BUILD_DATE" ]; then
		success "Return SW Version"
	else
		failure "Return SW Version"
	fi
}
######################################################################
# Function:     set_dev_info_after_511
# Purpose:      Disable diagnostics and change idme file
# Parameters:    none
# Returns:      none
######################################################################
set_dev_info_after_511()
{
        doppler-idme --key boot.bootmode --val main-A || return 1
        doppler-idme --key boot.knowngood --val main-B || return 1
        doppler-idme --key boot.otaretrycount --val 2 || return 1
        doppler-idme --key boot.postmode --val backup || return 1
        return 0
}
######################################################################
# Function:     disable_diags
# Purpose:      Disable diagnostics
# Parameters:    none
# Returns:      none
######################################################################
disable_diags()
{
	local bootmode
	local knowngood

        set_dev_info_after_511
        if [ $? -ne 0 ];then
        return 1
        fi
	sync
	bootmode=$(doppler-idme --key boot.bootmode)
	knowngood=$(doppler-idme --key boot.knowngood)
        if [ $bootmode = "main-A" ] && [ $knowngood = "main-B" ] ; then
		success "Disable diagnostics"
	else
		failure "Disable diagnostics"
	fi
	return 0
}


######################################################################
# Function:     run_ExitRbootDisable_menu
# Purpose:      Drives ExitRbootDisable module menu
# Parameters:    none
# Returns:      0: exit ExitRbootDisable_menu
#		        1: exit ExitRbootDisable_menu and reboot system
#		        2: exit ExitRbootDisable_menu and auto run the user system
######################################################################
run_ExitRbootDisable_menu()
{
    local DO_EXIT=0
    local REDRAW_MENU=0
    local RET=0
	local KEY
	
    while [ $DO_EXIT -ne 1 ]; do
        if [ $REDRAW_MENU -eq 0 ]; then
			display_ExitRbootDisable_menu
        else
        	REDRAW_MENU=0
        fi
        
		KEY=`get_char`
		echo " "
        case "$KEY" in
        v | V)
            do_local_echo "Return SW version selected"
            return_sw_version
            ;;
            
        u | U)
            do_local_echo "MMC bundle install selected"
            $RUN_SWUPDATE
            ;;
            
        c | C)
            do_local_echo "Check PASS/FAIL status selected"
            display_diag_result_summary
            ;;
            
        r | R)
            do_local_echo "Reboot system selected"
            DO_EXIT=1
            RET=1
            ;;
            
        d | D)
            do_local_echo "Disable diagnostics selected"
            disable_diags
            # DO_EXIT=1
			# RET=2
            ;;
            
        x | X)
            DO_EXIT=1
            RET=0
            ;;
            
        *)
            REDRAW_MENU=1
            ;;
        esac
    done
    
    return $RET
}

######################################################################
# Function:     run_diagnostic_menu
# Purpose:      Drives main diagnostic menu
# Parameters:    none
# Returns:      0 - Diags have not yet been disabled
#               1 - Diags will be reboot
######################################################################
run_diagnostic_menu()
{
    local DO_RETURN=0
    local DONT_REDRAW_MENU=0
    DIAGS_HAVE_BEEN_DISABLED=0
    local KEY

    # Report System Diagnostic information to logfile
    vmsg "$PRODUCT_NAME Diagnostic Services $DIAGNOSTICS_BUILD $DIAGNOSTICS_VERSION"
    vmsg "Diag FS Version: $DIAG_SOFTWARE_FS_VERSION"
    vmsg "Diag Build Date: $DIAG_SOFTWARE_FS_BUILD_DATE"

    # Process user requests
    while [ $DO_RETURN -ne 1 ]; do

    # Put up main diagnostic menu
    #
        if [ $DONT_REDRAW_MENU -eq 0 ]; then
            display_menu
        else
            # DONT_REDRAW_MENU is a one-shot, so reset it now
            DONT_REDRAW_MENU=0
        fi

    #
    # Get the key request
    #
        KEY=`get_char`
        echo " "
        
    #
    # Process key request
    case "$KEY" in
        s | S)
            vmsg "Launching device settings module..."
            ${RUN_DEVICE_SETTINGS}    # start to test device setting test...
            local REBOOT_DEVICE="$?"  # $?: 1-->reboot, 0-->normal
            if [ ${REBOOT_DEVICE} -eq 1 ]; then
                # Setting device parameters requires a reboot...
                do_local_echo  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
                do_local_echo "Rebooting now so changes take effect..."
                DO_RETURN=1
                DIAGS_HAVE_BEEN_DISABLED=1
            fi
            ;;
            
        o | O)
            vmsg "Starting Operator Suite..."
            do_local_echo "Operator Test Suite selected"
            ${RUN_OPERATOR}
            ;;
        
        r | R)
            vmsg "Displaying Run-in enable menu..."
            do_local_echo "Run-in selected"
            # It takes the run modes feature a few seconds to initialize
            # as it includes all the hals...
            # Put up a screen here informing user that we're processing their request...
		    do_local_echo "Run-in Test"
		    do_local_echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		    do_local_echo "Initializing Run-in module now..."

            ${RUN_MODES}
            ;; 
        
        e | E)
            vmsg "Starting 511 Test..."
            do_local_echo "511 selected"
            ${RUN_511_TEST}
            ;;
        
        t | T)
            vmsg "Starting Power Test..."
            do_local_echo "Power selected"
            ${RUN_POWER}
            ;; 
        
        a | A)
            vmsg "Starting Audio Test..."
            do_local_echo "Audio selected"
            ${RUN_AUDIO}
            ;;                   

        m | M)
            vmsg "RMA selected..."
            do_local_echo "RMA selected"
            ${RUN_RMA}
            ;;
        
        n | N)
            vmsg "Diagnostic Misc. Menu selected..."
            do_local_echo "Diagnostic Misc. Menu selected"
            run_diagnostic_misc_menu
            ;;

        d | D)
            vmsg "Exit, Reboot or Disable Diags selected"
            do_local_echo "Exit, Reboot or Disable Diags selected"
            run_ExitRbootDisable_menu
        
            local GET_RETURN=$?  #get return value: 0-->normal exit; 1-->reboot; 2-->disable diags
            if [ "${GET_RETURN}" -eq 1 ]; then
                do_local_echo  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
                do_local_echo "Rebooting now so changes take effect..."
                DO_RETURN=1
                DIAGS_HAVE_BEEN_DISABLED=1
            elif [ ${GET_RETURN} -eq 2 ]; then
                DO_RETURN=1
                DIAGS_HAVE_BEEN_DISABLED=2
            fi
            ;;
        v | V)
            ${RUN_VOICE}
            ;;
        f | F)
            ${RUN_FQC}
            ;;
        p | P)
            ${RUN_PAIRING}
            ;;
        x | X)
            vmsg "Exiting Diagnostic Services..."
            do_local_echo "Exit Diagnostic Services selected"
            DO_RETURN=1
            ;;

        *)
            DONT_REDRAW_MENU=1
            ;;
        esac
    done
    return $DIAGS_HAVE_BEEN_DISABLED
}

#export NAND_CHECK_RESULT=0  ## default value : 0---PASS;others--FAIL

check_env()
{
	local nand_need_check_flag="/test/factory/nand_need_check"
	if [ -e "/dev/mmcblk0" ];then ##ISP or SWDL
		return 0
	elif [ -f $nand_need_check_flag ];then ## first boot up
		echo
		do_local_echo "nand check flag detected"
		#rm -rf $nand_need_check_flag
		return 1
	fi
	return 0
}

######################################################################
#
#    maximum number of bad blocks for nand : 80
#
#   maximum number of bad blocks for partitions
#   mtd0     0x000000000000-0x000000080000 : "X-Loader"                   2
#   mtd1     0x000000080000-0x000000140000 : "U-Boot-Main"            2
#   mtd2     0x000000140000-0x000000200000 : "U-Boot-Rec"               2
#   mtd3     0x000000200000-0x000000280000 : "Data-MFG"                 2
#   mtd4     0x000000280000-0x000000780000 : "Kernel-DIAG"             10
#   mtd5     0x000000780000-0x000002780000 : "FS-DIAG"                    10
#   mtd6     0x000002780000-0x000002c80000 : "Kernel-Main"
#   mtd7     0x000002c80000-0x000017180000 : "FS-Main"
#   mtd8     0x000017180000-0x000020000000 : "Data"                            20
#   mtd9     0x000002780000-0x000002c80000 : "Kernel-Main-A"           10
#   mtd10   0x000002c80000-0x00000cc80000 : "FS-Main-A"                  25
#   mtd11   0x00000cc80000-0x00000d180000 : "Kernel-Main-B"           10
#   mtd12   0x00000d180000-0x000017180000 : "FS-Main-B"                 25
######################################################################
nand_check()
{
	local nand_need_check_flag="/test/factory/nand_need_check"
#	local partition_num="0 1 2 3 4 5 8 9 10 11 12"
	local bad_blk_limit="2 2 2 2 10 10 20 10 25 10 25"
	local bad_blk_num
	local total_bad_blk=0
	local total_bad_blk_limit=80
	local num=0
	local limit

	check_env
	if [ $? -eq 0 ];then
		return 0
	fi

	do_local_echo "Checking nand for bad blocks ..."
	for limit in $bad_blk_limit
	do
		bad_blk_num=`block-check -m /dev/mtd${num} | grep "bad blocks" | awk '{print $6}'`
		let total_bad_blk=$total_bad_blk+$bad_blk_num
		do_local_echo "/dev/mtd${num}: $bad_blk_num"

		if [ $limit -lt $bad_blk_num ];then
			export NAND_CHECK_RESULT=$num
			do_local_echo "/dev/mtd$num has too many bad blocks!"
#			sync
#			return $num
		fi
		
		if [ $num -eq 5 ];then
			let num=$num+3   ## ignore mtd6 and mtd7
		else
			let num=$num+1
		fi
		
	done
	do_local_echo "Entire nand:$total_bad_blk"
	if [ $total_bad_blk_limit -lt $total_bad_blk ];then
		export NAND_CHECK_RESULT=$total_bad_blk
		do_local_echo "The entire nand has too many bad blocks!"
	fi
	do_local_echo

	if [ $NAND_CHECK_RESULT -ne 0 ];then
		display_dsn_pcbid_mainmenu  ## display pcbsn for GUI
		failure "Pre-flash"
		exit 1
	elif [ $NAND_CHECK_RESULT -eq 0 ];then
		rm -rf $nand_need_check_flag
#		set_boot_mode_diags  ## set bootmode to diags
		sync
		return 0
	fi
}

led_disable_animation()
{
	local led_node_dir="/sys/class/i2c-dev/i2c-2/device"
	local engine_mode_list="engine1_mode engine2_mode engine3_mode"
	local engine_mode
	for engine_mode in $engine_mode_list
	do
		if [ -e "$led_node_dir/2-0032/$engine_mode" ]; then
			echo "disabled" > $led_node_dir/2-0032/$engine_mode
		fi
		if [ -e "$led_node_dir/2-0033/$engine_mode" ]; then
			echo "disabled" > $led_node_dir/2-0033/$engine_mode
		fi
		if [ -e "$led_node_dir/2-0034/$engine_mode" ]; then
			echo "disabled" > $led_node_dir/2-0034/$engine_mode
		fi
		if [ -e "$led_node_dir/2-0035/$engine_mode" ]; then
			echo "disabled" > $led_node_dir/2-0035/$engine_mode
		fi
	done
	led_set_colour "d"
}

## <---start here!
case "$1" in

    stop)
        do_local_echo "Stopping Diagnostic Services..."
        ;;

    start|*)
        do_local_echo "Starting Diagnostic Services..."
        # Set printk level up to maximum
        echo 0 > /proc/sys/kernel/printk
	
		#set asound state --remove it 20130624
		#alsactl restore -f /test/factory/tests/audio/asound.state
		
        # Load up file system version, date variables
        get_sw_version
		
		if ! [ -e /Data ];then
			mkdir /Data
		fi

		## make the logfile folder if doesn't exist
		## save copy the older logfilses to a timestamp folder and remove them
		do_enable_console_logfile
        init_diaglog
		## running nand check for bad blocks
		# nand_check
		## add 20130713
		led_disable_animation
        #check whether we should do auto runin Test
        check_auto_runin_flag
        if [ $AUTO_RUNIN_FLAG -eq 1 ];then
        	open_save_runin_log
        	run_modes_hal_init
        	get_runin_args_from_file
        	do_auto_runin_test
			RESULT="$?"
        	runin_display_result_dialog "$RESULT"
        	close_save_runin_log
        else
	        do_local_echo "Displaying main System Diags Menu"
		    
	        run_diagnostic_menu
	  		## 0:exit to console; 1:reboot; 2:disable diags
	        diags_disabled="$?"
	        display_diag_result_summary
	        dump_diaglog
		    
			# del at 0907. move this function to init_diaglog()
	        # Save logfile, don't overwrite (make unique)
	        # save_diaglog 0 0 0 0
	        
	        if [ $diags_disabled -eq 0 ]; then
	        	## exit to console
	        	exit 0
	  	   elif [ $diags_disabled -eq 1 ]; then
	    		## If user didn't disable diags, we're back here again...
	    		# reboot
				exit 0
	        elif [ $diags_disabled -eq 2 ]; then
	    		display_user_disable_autorun_screen 1
	    		# reboot
	      	fi
	    fi
        ;;
esac

